import { FarmAnimal } from "../model/FarmAnimal";
import { Chicken } from "../model/Chicken";
import { Cow } from "../model/Cow";
import { Pig } from "../model/Pig";
import { Sheep } from "../model/Sheep";
import { Hydrate } from "../model/Hydrate";
import { Vaccinable } from "../model/Vaccinable";

/**
 * @author Marcos Mamarandi, @ESPE
 */
export function main(): void {
    let farmAnimal: FarmAnimal;

    console.log("Marcos's Farm App");
    console.log("Author: Marcos Mamarandi");
    console.log("=======================");

    // En JavaScript los meses van de 0 a 11 (9 = octubre, 11 = diciembre)
    farmAnimal = new Chicken(false, 10, 2, "palish", new Date(2022, 9, 10));
    console.log("chicken --->" + farmAnimal);
    console.log("chicken is a --->class " + farmAnimal.constructor.name); // getClass()
    console.log("chicken is a --->" + farmAnimal.constructor.name);       // getSimpleName()

    const chicken = new Chicken(false, 10, 2, "palish", new Date(2022, 9, 10));
    console.log("chicken --->" + chicken);
    console.log("chicken is a --->" + chicken.constructor.name);

    const cow = new Cow(true, 23.5, 3, "Holstein", new Date(2024, 11, 23), false);
    console.log("cow --->" + cow);
    console.log("cow is a --->" + cow.constructor.name);

    const pig = new Pig(true, 30.23, 4, "Mangalitsa", new Date(2019, 10, 30), false);
    console.log("pig --->" + pig);
    console.log("pig is a --->" + pig.constructor.name);

    const sheep = new Sheep(true, new Date(2025, 10, 24), 5, "Manchega", new Date(2024, 8, 27), true);
    console.log("sheep --->" + sheep);
    console.log("sheep is a --->" + sheep.constructor.name);

    chicken.layAnEgg();
    cow.milk();
    pig.showPigMeatCuts();
    sheep.shearSheep();

    console.log("=======================");
    console.log("Interfaces: Hydrate and Vaccinable");

    let drinker: Hydrate = pig;
    drinker.drinkWater(8.5);
    drinker = sheep;
    drinker.drinkWater(4);

    let patient: Vaccinable = pig;
    patient.vaccinate("Swine flu");
    console.log("pig vaccinated --->" + patient.isVaccinated());
    patient = sheep;
    console.log("sheep vaccinated --->" + patient.isVaccinated());
    patient.vaccinate("Clostridial");
    console.log("sheep vaccinated --->" + patient.isVaccinated());

    pig.rootForFood();
    console.log("pig is overweight --->" + pig.isOverweight(150, 120));
    sheep.bleat();
    console.log("wool in 6 months (kg) --->" + sheep.calculateWoolProduction(0.4, 6));

    console.log("=======================");
    console.log("Program by Marcos Mamarandi");
}
