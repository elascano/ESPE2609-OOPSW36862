/**
 * Interface for animals that can receive vaccines.
 * @author Marcos Mamarandi, @ESPE
 */
export interface Vaccinable {
    vaccinate(vaccineName: string): void;
    isVaccinated(): boolean;
}
