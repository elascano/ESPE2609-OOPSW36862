import { FarmAnimal } from "./FarmAnimal";
import { Hydrate } from "./Hydrate";
import { Vaccinable } from "./Vaccinable";

/**
 * @author Marcos Mamarandi, @ESPE
 */
export class Pig extends FarmAnimal implements Hydrate, Vaccinable {
    private _isWallowing: boolean;
    private _weightGainPerWeek: number;
    private _vaccinated: boolean;

    constructor(isWallowing: boolean, weightGainPerWeek: number,
                id: number, breed: string, bornOnDate: Date, isMeat: boolean) {
        super(id, breed, bornOnDate, isMeat);
        this._isWallowing = isWallowing;
        this._weightGainPerWeek = weightGainPerWeek;
        this._vaccinated = false;
    }

    public showPigMeatCuts(): void {
        const meatCuts: string[] = ["head", "cheek", "picnic", "clear plate", "boston shoulder",
            "back fat", "loin", "ribs", "bacon", "leg", "ham", "hock"];
        console.log("Avalaible cuts for the pig" + "[" + meatCuts.join(", ") + "]");
    }

    // ---------- interface Hydrate ----------
    public drinkWater(liters: number): void {
        console.log("pig " + this.id + " drank " + liters + " liters of water");
    }

    // ---------- interface Vaccinable ----------
    public vaccinate(vaccineName: string): void {
        this._vaccinated = true;
        console.log("pig " + this.id + " received the vaccine " + vaccineName);
    }

    public isVaccinated(): boolean {
        return this._vaccinated;
    }

    // ---------- new methods ----------
    public rootForFood(): void {
        console.log("pig " + this.id + " is rooting the ground looking for food");
    }

    public isOverweight(currentWeight: number, idealWeight: number): boolean {
        return currentWeight > idealWeight;
    }

    public override toString(): string {
        return "Pig{" + super.toString() + "isWallowing=" + this._isWallowing +
            ", weightGainPerWeek=" + this._weightGainPerWeek + "}";
    }

    public get isWallowing(): boolean { return this._isWallowing; }
    public set isWallowing(value: boolean) { this._isWallowing = value; }

    public get weightGainPerWeek(): number { return this._weightGainPerWeek; }
    public set weightGainPerWeek(value: number) { this._weightGainPerWeek = value; }
}
