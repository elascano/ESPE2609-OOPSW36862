import { FarmAnimal } from "./FarmAnimal";
import { Hydrate } from "./Hydrate";
import { Vaccinable } from "./Vaccinable";

/**
 * @author Marcos Mamarandi, @ESPE
 */
export class Sheep extends FarmAnimal implements Hydrate, Vaccinable {
    private _isSheared: boolean;
    private _lastSheering: Date;
    private _vaccinated: boolean;

    constructor(isSheared: boolean, lastSheering: Date,
                id: number, breed: string, bornOnDate: Date, isMeat: boolean) {
        super(id, breed, bornOnDate, isMeat);
        this._isSheared = isSheared;
        this._lastSheering = lastSheering;
        this._vaccinated = false;
    }

    public shearSheep(): void {
        this._isSheared = true;
        this._lastSheering = new Date();
        console.log("Sheep is sheared");
    }

    // ---------- interface Hydrate ----------
    public drinkWater(liters: number): void {
        console.log("sheep " + this.id + " drank " + liters + " liters of water");
    }

    // ---------- interface Vaccinable ----------
    public vaccinate(vaccineName: string): void {
        this._vaccinated = true;
        console.log("sheep " + this.id + " received the vaccine " + vaccineName);
    }

    public isVaccinated(): boolean {
        return this._vaccinated;
    }

    // ---------- new methods ----------
    public bleat(): void {
        console.log("sheep " + this.id + " says: baaaa!");
    }

    public calculateWoolProduction(kilogramsPerMonth: number, months: number): number {
        return kilogramsPerMonth * months;
    }

    public override toString(): string {
        return "Sheep{" + super.toString() + "isSheared=" + this._isSheared +
            ", lastSheering=" + FarmAnimal.formatDate(this._lastSheering) + "}";
    }

    public get isSheared(): boolean { return this._isSheared; }
    public set isSheared(value: boolean) { this._isSheared = value; }

    public get lastSheering(): Date { return this._lastSheering; }
    public set lastSheering(value: Date) { this._lastSheering = value; }
}
