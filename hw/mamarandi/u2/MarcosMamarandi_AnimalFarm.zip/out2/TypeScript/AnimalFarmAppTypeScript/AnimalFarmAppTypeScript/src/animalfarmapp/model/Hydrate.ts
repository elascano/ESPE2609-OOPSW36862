/**
 * Interface for animals that need to drink water.
 * @author Marcos Mamarandi, @ESPE
 */
export interface Hydrate {
    drinkWater(liters: number): void;
}
