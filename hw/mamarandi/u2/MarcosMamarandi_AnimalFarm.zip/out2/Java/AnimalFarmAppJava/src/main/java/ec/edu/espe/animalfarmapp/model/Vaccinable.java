package ec.edu.espe.animalfarmapp.model;

/**
 * Interface for animals that can receive vaccines.
 *
 * @author Marcos Mamarandi, @ESPE
 */
public interface Vaccinable {

    void vaccinate(String vaccineName);

    boolean isVaccinated();
}
