package ec.edu.espe.animalfarmapp.model;

import java.util.Arrays;
import java.util.Date;

/**
 *
 * @author Marcos Mamarandi, @ESPE
 */
public class Pig extends FarmAnimal implements Hydrate, Vaccinable {

    private boolean isWallowing;
    private float weightGainPerWeek;
    private boolean vaccinated;

    public Pig(boolean isWallowing, float weightGainPerWeek, int id, String breed, Date bornOnDate, boolean isMeat) {
        super(id, breed, bornOnDate, isMeat);
        this.isWallowing = isWallowing;
        this.weightGainPerWeek = weightGainPerWeek;
        this.vaccinated = false;
    }

    public void showPigMeatCuts() {
        String meatCuts[] = {"head", "cheek", "picnic", "clear plate", "boston shoulder", "back fat", "loin", "ribs", "bacon", "leg", "ham", "hock"};
        System.out.println("Avalaible cuts for the pig" + Arrays.toString(meatCuts));
    }

    // ---------- interface Hydrate ----------
    @Override
    public void drinkWater(float liters) {
        System.out.println("pig " + getId() + " drank " + liters + " liters of water");
    }

    // ---------- interface Vaccinable ----------
    @Override
    public void vaccinate(String vaccineName) {
        vaccinated = true;
        System.out.println("pig " + getId() + " received the vaccine " + vaccineName);
    }

    @Override
    public boolean isVaccinated() {
        return vaccinated;
    }

    // ---------- new methods ----------
    public void rootForFood() {
        System.out.println("pig " + getId() + " is rooting the ground looking for food");
    }

    public boolean isOverweight(float currentWeight, float idealWeight) {
        return currentWeight > idealWeight;
    }

    @Override
    public String toString() {
        return "Pig{" + super.toString() + "isWallowing=" + isWallowing + ", weightGainPerWeek=" + weightGainPerWeek + '}';
    }

    public boolean isIsWallowing() {
        return isWallowing;
    }

    public void setIsWallowing(boolean isWallowing) {
        this.isWallowing = isWallowing;
    }

    public double getWeightGainPerWeek() {
        return weightGainPerWeek;
    }

    public void setWeightGainPerWeek(float weightGainPerWeek) {
        this.weightGainPerWeek = weightGainPerWeek;
    }
}
