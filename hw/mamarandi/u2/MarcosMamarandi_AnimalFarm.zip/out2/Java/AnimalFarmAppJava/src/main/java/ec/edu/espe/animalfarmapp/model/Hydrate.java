package ec.edu.espe.animalfarmapp.model;

/**
 * Interface for animals that need to drink water.
 *
 * @author Marcos Mamarandi, @ESPE
 */
public interface Hydrate {

    void drinkWater(float liters);
}
