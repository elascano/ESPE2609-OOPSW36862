package ec.edu.espe.animalfarmapp.view;

import ec.edu.espe.animalfarmapp.model.Chicken;
import ec.edu.espe.animalfarmapp.model.Cow;
import ec.edu.espe.animalfarmapp.model.FarmAnimal;
import ec.edu.espe.animalfarmapp.model.Hydrate;
import ec.edu.espe.animalfarmapp.model.Pig;
import ec.edu.espe.animalfarmapp.model.Sheep;
import ec.edu.espe.animalfarmapp.model.Vaccinable;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author Marcos Mamarandi, @ESPE
 */
public class AnimalFarmApp {

    // year, month (1-12), day
    private static Date date(int year, int month, int day) {
        return new GregorianCalendar(year, month - 1, day).getTime();
    }

    public static void main(String[] args) {
        FarmAnimal farmAnimal;

        System.out.println("Marcos's Farm App");
        System.out.println("Author: Marcos Mamarandi");
        System.out.println("=======================");

        farmAnimal = new Chicken(false, 10, 2, "palish", date(2022, 10, 10));
        System.out.println("chicken --->" + farmAnimal);
        System.out.println("chicken is a --->" + farmAnimal.getClass());
        System.out.println("chicken is a --->" + farmAnimal.getClass().getSimpleName());

        Chicken chicken = new Chicken(false, 10, 2, "palish", date(2022, 10, 10));
        System.out.println("chicken --->" + chicken);
        System.out.println("chicken is a --->" + chicken.getClass().getSimpleName());

        Cow cow = new Cow(true, 23.5F, 3, "Holstein", date(2024, 12, 23), false);
        System.out.println("cow --->" + cow);
        System.out.println("cow is a --->" + cow.getClass().getSimpleName());

        Pig pig = new Pig(true, 30.23F, 4, "Mangalitsa", date(2019, 11, 30), false);
        System.out.println("pig --->" + pig);
        System.out.println("pig is a --->" + pig.getClass().getSimpleName());

        Sheep sheep = new Sheep(true, date(2025, 11, 24), 5, "Manchega", date(2024, 9, 27), true);
        System.out.println("sheep --->" + sheep);
        System.out.println("sheep is a --->" + sheep.getClass().getSimpleName());

        chicken.layAnEgg();
        cow.milk();
        pig.showPigMeatCuts();
        sheep.shearSheep();

        System.out.println("=======================");
        System.out.println("Interfaces: Hydrate and Vaccinable");

        Hydrate drinker = pig;
        drinker.drinkWater(8.5F);
        drinker = sheep;
        drinker.drinkWater(4F);

        Vaccinable patient = pig;
        patient.vaccinate("Swine flu");
        System.out.println("pig vaccinated --->" + patient.isVaccinated());
        patient = sheep;
        System.out.println("sheep vaccinated --->" + patient.isVaccinated());
        patient.vaccinate("Clostridial");
        System.out.println("sheep vaccinated --->" + patient.isVaccinated());

        pig.rootForFood();
        System.out.println("pig is overweight --->" + pig.isOverweight(150F, 120F));
        sheep.bleat();
        System.out.println("wool in 6 months (kg) --->" + sheep.calculateWoolProduction(0.4F, 6));

        System.out.println("=======================");
        System.out.println("Program by Marcos Mamarandi");
    }
}
