package ec.edu.espe.animalfarmapp.model;

import java.util.Date;

/**
 *
 * @author Marcos Mamarandi, @ESPE
 */
public class Sheep extends FarmAnimal implements Hydrate, Vaccinable {

    private boolean isSheared;
    private Date lastSheering;
    private boolean vaccinated;

    public Sheep(boolean isSheared, Date lastSheering, int id, String breed, Date bornOnDate, boolean isMeat) {
        super(id, breed, bornOnDate, isMeat);
        this.isSheared = isSheared;
        this.lastSheering = lastSheering;
        this.vaccinated = false;
    }

    public void shearSheep() {
        isSheared = true;
        lastSheering = new Date();
        System.out.println("Sheep is sheared");
    }

    // ---------- interface Hydrate ----------
    @Override
    public void drinkWater(float liters) {
        System.out.println("sheep " + getId() + " drank " + liters + " liters of water");
    }

    // ---------- interface Vaccinable ----------
    @Override
    public void vaccinate(String vaccineName) {
        vaccinated = true;
        System.out.println("sheep " + getId() + " received the vaccine " + vaccineName);
    }

    @Override
    public boolean isVaccinated() {
        return vaccinated;
    }

    // ---------- new methods ----------
    public void bleat() {
        System.out.println("sheep " + getId() + " says: baaaa!");
    }

    public float calculateWoolProduction(float kilogramsPerMonth, int months) {
        return kilogramsPerMonth * months;
    }

    @Override
    public String toString() {
        return "Sheep{" + super.toString() + "isSheared=" + isSheared + ", lastSheering=" + lastSheering + '}';
    }

    public boolean isIsSheared() {
        return isSheared;
    }

    public void setIsSheared(boolean isSheared) {
        this.isSheared = isSheared;
    }

    public Date getLastSheering() {
        return lastSheering;
    }

    public void setLastSheering(Date lastSheering) {
        this.lastSheering = lastSheering;
    }
}
