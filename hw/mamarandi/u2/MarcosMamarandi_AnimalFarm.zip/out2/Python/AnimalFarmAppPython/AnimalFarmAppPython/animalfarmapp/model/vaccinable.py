from abc import ABC, abstractmethod

# @author Marcos Mamarandi, @ESPE


class Vaccinable(ABC):
    """Interface for animals that can receive vaccines."""

    @abstractmethod
    def vaccinate(self, vaccine_name: str) -> None:
        pass

    @abstractmethod
    def is_vaccinated(self) -> bool:
        pass
