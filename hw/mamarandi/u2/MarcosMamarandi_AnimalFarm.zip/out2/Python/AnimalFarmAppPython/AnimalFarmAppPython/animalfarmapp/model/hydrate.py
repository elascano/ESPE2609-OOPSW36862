from abc import ABC, abstractmethod

# @author Marcos Mamarandi, @ESPE


class Hydrate(ABC):
    """Interface for animals that need to drink water."""

    @abstractmethod
    def drink_water(self, liters: float) -> None:
        pass
