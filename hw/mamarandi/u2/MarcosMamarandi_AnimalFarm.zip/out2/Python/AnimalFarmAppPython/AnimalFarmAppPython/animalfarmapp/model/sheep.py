from datetime import date
from animalfarmapp.model.farm_animal import FarmAnimal
from animalfarmapp.model.hydrate import Hydrate
from animalfarmapp.model.vaccinable import Vaccinable

# @author Marcos Mamarandi, @ESPE


class Sheep(FarmAnimal, Hydrate, Vaccinable):

    def __init__(self, is_sheared: bool, last_sheering: date,
                 id: int, breed: str, born_on_date: date, is_meat: bool):
        super().__init__(id, breed, born_on_date, is_meat)
        self._is_sheared = is_sheared
        self._last_sheering = last_sheering
        self._vaccinated = False

    def shear_sheep(self):
        self._is_sheared = True
        self._last_sheering = date.today()
        print("Sheep is sheared")

    # ---------- interface Hydrate ----------
    def drink_water(self, liters: float) -> None:
        print(f"sheep {self.id} drank {liters} liters of water")

    # ---------- interface Vaccinable ----------
    def vaccinate(self, vaccine_name: str) -> None:
        self._vaccinated = True
        print(f"sheep {self.id} received the vaccine {vaccine_name}")

    def is_vaccinated(self) -> bool:
        return self._vaccinated

    # ---------- new methods ----------
    def bleat(self) -> None:
        print(f"sheep {self.id} says: baaaa!")

    def calculate_wool_production(self, kilograms_per_month: float, months: int) -> float:
        return kilograms_per_month * months

    def __str__(self) -> str:
        return ("Sheep{" + super().__str__()
                + f"isSheared={self._is_sheared}, "
                + f"lastSheering={self.format_date(self._last_sheering)}" + "}")

    @property
    def is_sheared(self) -> bool:
        return self._is_sheared

    @is_sheared.setter
    def is_sheared(self, value: bool):
        self._is_sheared = value

    @property
    def last_sheering(self) -> date:
        return self._last_sheering

    @last_sheering.setter
    def last_sheering(self, value: date):
        self._last_sheering = value
