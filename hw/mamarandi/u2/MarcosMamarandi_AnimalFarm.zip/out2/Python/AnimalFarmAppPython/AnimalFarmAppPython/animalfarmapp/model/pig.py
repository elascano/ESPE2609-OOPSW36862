from datetime import date
from animalfarmapp.model.farm_animal import FarmAnimal
from animalfarmapp.model.hydrate import Hydrate
from animalfarmapp.model.vaccinable import Vaccinable

# @author Marcos Mamarandi, @ESPE


class Pig(FarmAnimal, Hydrate, Vaccinable):

    def __init__(self, is_wallowing: bool, weight_gain_per_week: float,
                 id: int, breed: str, born_on_date: date, is_meat: bool):
        super().__init__(id, breed, born_on_date, is_meat)
        self._is_wallowing = is_wallowing
        self._weight_gain_per_week = weight_gain_per_week
        self._vaccinated = False

    def show_pig_meat_cuts(self):
        meat_cuts = ["head", "cheek", "picnic", "clear plate", "boston shoulder",
                     "back fat", "loin", "ribs", "bacon", "leg", "ham", "hock"]
        print("Avalaible cuts for the pig" + "[" + ", ".join(meat_cuts) + "]")

    # ---------- interface Hydrate ----------
    def drink_water(self, liters: float) -> None:
        print(f"pig {self.id} drank {liters} liters of water")

    # ---------- interface Vaccinable ----------
    def vaccinate(self, vaccine_name: str) -> None:
        self._vaccinated = True
        print(f"pig {self.id} received the vaccine {vaccine_name}")

    def is_vaccinated(self) -> bool:
        return self._vaccinated

    # ---------- new methods ----------
    def root_for_food(self) -> None:
        print(f"pig {self.id} is rooting the ground looking for food")

    def is_overweight(self, current_weight: float, ideal_weight: float) -> bool:
        return current_weight > ideal_weight

    def __str__(self) -> str:
        return ("Pig{" + super().__str__()
                + f"isWallowing={self._is_wallowing}, "
                + f"weightGainPerWeek={self._weight_gain_per_week}" + "}")

    @property
    def is_wallowing(self) -> bool:
        return self._is_wallowing

    @is_wallowing.setter
    def is_wallowing(self, value: bool):
        self._is_wallowing = value

    @property
    def weight_gain_per_week(self) -> float:
        return self._weight_gain_per_week

    @weight_gain_per_week.setter
    def weight_gain_per_week(self, value: float):
        self._weight_gain_per_week = value
