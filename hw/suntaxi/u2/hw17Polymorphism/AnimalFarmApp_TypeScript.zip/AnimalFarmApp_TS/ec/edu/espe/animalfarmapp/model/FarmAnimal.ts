export abstract class FarmAnimal {
    protected name: string;
    protected age: number;
    protected breed: string;

    constructor(name: string, age: number, breed: string) {
        this.name = name;
        this.age = age;
        this.breed = breed;
    }

    public abstract makeSound(): string;

    public toString(): string {
        return `${this.constructor.name} [Nombre: ${this.name}, Edad: ${this.age}, Raza: ${this.breed}]`;
    }
}
