import { FarmAnimal } from '../model/FarmAnimal';
import { Chicken } from '../model/Chicken';
import { Cow } from '../model/Cow';

class AnimalFarmApp {
    public static main(): void {
        console.log("ANIMAL FARM APP");

        const chicken = new Chicken("Pepa", 1, "Rhode Island Red", false);
        const cow = new Cow("Margarita", 4, "Holstein", 22.5);

        const farmAnimals: FarmAnimal[] = [chicken, cow];

        for (const animal of farmAnimals) {
            console.log(`\nInformación: ${animal.toString()}`);
            console.log(`Sonido: ${animal.makeSound()}`);

            if (animal instanceof Chicken) {
                console.log(animal.layEgg());
            } else if (animal instanceof Cow) {
                console.log(animal.produceMilk());
            }
        }
    }
}

AnimalFarmApp.main();
