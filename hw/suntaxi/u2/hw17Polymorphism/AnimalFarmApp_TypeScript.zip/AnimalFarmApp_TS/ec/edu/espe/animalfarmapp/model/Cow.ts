import { FarmAnimal } from './FarmAnimal';

export class Cow extends FarmAnimal {
    private milkProductionLiters: number;

    constructor(name: string, age: number, breed: string, milkProductionLiters: number) {
        super(name, age, breed);
        this.milkProductionLiters = milkProductionLiters;
    }

    public makeSound(): string {
        return "Muuu";
    }

    public produceMilk(): string {
        return `${this.name} ha producido ${this.milkProductionLiters} litros de leche.`;
    }
}
