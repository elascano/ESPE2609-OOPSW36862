import { FarmAnimal } from './FarmAnimal';

export class Chicken extends FarmAnimal {
    private isMolting: boolean;

    constructor(name: string, age: number, breed: string, isMolting: boolean = false) {
        super(name, age, breed);
        this.isMolting = isMolting;
    }

    public makeSound(): string {
        return "Cluck, cluck";
    }

    public layEgg(): string {
        return `${this.name} ha puesto un huevo fresco.`;
    }
}
