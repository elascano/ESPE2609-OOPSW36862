from datetime import date, datetime

from ec.edu.espe.animalfarmapp.model.farm_animal import FarmAnimal


class Sheep(FarmAnimal):
    def __init__(self, last_sheering: datetime, id: int, breed: str, born_on_date: date):
        super().__init__(id, breed, born_on_date)
        self._last_sheering = last_sheering

    def sheering(self) -> None:
        print("Las sheering in")

    def __str__(self) -> str:
        shown = self._last_sheering.strftime("%a %b %d %H:%M:%S %Y")
        return f"Sheep{{{super().__str__()}lastSheering={shown}}}"

    @property
    def last_sheering(self) -> datetime:
        return self._last_sheering

    @last_sheering.setter
    def last_sheering(self, value: datetime) -> None:
        self._last_sheering = value
