from datetime import date

from ec.edu.espe.animalfarmapp.model.farm_animal import FarmAnimal


class Pig(FarmAnimal):
    def __init__(self, is_delicious: bool, id: int, breed: str, born_on_date: date):
        super().__init__(id, breed, born_on_date)
        self._is_delicious = is_delicious

    def __str__(self) -> str:
        return f"Pig{{{super().__str__()}isDelicious={str(self._is_delicious).lower()}}}"

    @property
    def is_delicious(self) -> bool:
        return self._is_delicious

    @is_delicious.setter
    def is_delicious(self, value: bool) -> None:
        self._is_delicious = value
