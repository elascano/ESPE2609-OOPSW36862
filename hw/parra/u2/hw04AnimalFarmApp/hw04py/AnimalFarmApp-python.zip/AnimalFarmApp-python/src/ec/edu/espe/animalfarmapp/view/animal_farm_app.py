from datetime import date, datetime

from ec.edu.espe.animalfarmapp.model.chicken import Chicken
from ec.edu.espe.animalfarmapp.model.cow import Cow
from ec.edu.espe.animalfarmapp.model.farm_animal import FarmAnimal
from ec.edu.espe.animalfarmapp.model.pig import Pig
from ec.edu.espe.animalfarmapp.model.sheep import Sheep


def full_class_name(animal: FarmAnimal) -> str:
    return "class ec.edu.espe.animalfarmapp.model." + type(animal).__name__


def main() -> None:
    print("Hello this is Carlos's Animal Farm!")
    print("=====================================")

    born_on_date = date(2020, 11, 10)
    farm_animal: FarmAnimal = Cow(True, 6, 10, "houlstein", born_on_date)
    print("farmAnimal is a -->" + type(farm_animal).__name__)
    print("my farm animal -->" + str(farm_animal))

    chicken = Chicken(True, 10, True, 2, "Palish", date.today())
    print("Chicken -->" + str(chicken))
    chicken.lay_an_egg()

    far_animal_for_feeding: FarmAnimal = Chicken(True, 20, True, 30, "Palish", born_on_date)
    print("farAnimalForFeeding is a -->" + full_class_name(far_animal_for_feeding))
    print("farAnimalForFeeding is a -->" + type(far_animal_for_feeding).__name__)

    far_animal_for_feeding = Cow(True, 7, 5, "houlstein", born_on_date)
    print("farAnimalForFeeding is a -->" + type(far_animal_for_feeding).__name__)

    far_animal_for_feeding = Chicken(True, 5, True, 0, "Paliish", born_on_date)
    print("farAnimalForFeeding is a -->" + type(far_animal_for_feeding).__name__)
    print("Cow -->" + str(far_animal_for_feeding))

    cow = Cow(True, 10, 20, "hlstein", born_on_date)
    cow.milk()

    pig: FarmAnimal = Pig(True, 3, "Berkshire", date(2021, 4, 1))
    print("Pig -->" + str(pig))

    sheep: FarmAnimal = Sheep(datetime.now(), 4, "Merino", date(2023, 11, 5))
    print("Sheep -->" + str(sheep))


if __name__ == "__main__":
    main()
