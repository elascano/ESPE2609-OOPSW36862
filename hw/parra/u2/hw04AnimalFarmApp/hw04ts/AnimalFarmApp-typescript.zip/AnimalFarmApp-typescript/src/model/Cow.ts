import { FarmAnimal } from "./FarmAnimal.ts";

export class Cow extends FarmAnimal {
  private isProducingMilk: boolean;
  private litersOfMilkPerWeek: number;

  constructor(isProducingMilk: boolean, litersOfMilkPerWeek: number, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.isProducingMilk = isProducingMilk;
    this.litersOfMilkPerWeek = litersOfMilkPerWeek;
  }

  milk(): void {
    console.log("milk in the cow ");
  }

  override toString(): string {
    return "cow{" + super.toString() + "isProducingMilk=" + this.isProducingMilk +
      ", litersOfMilkPerWeek=" + this.formatLiters() + "}";
  }

  private formatLiters(): string {
    return Number.isInteger(this.litersOfMilkPerWeek)
      ? this.litersOfMilkPerWeek.toFixed(1)
      : String(this.litersOfMilkPerWeek);
  }

  getIsProducingMilk(): boolean { return this.isProducingMilk; }
  setIsProducingMilk(isProducingMilk: boolean): void { this.isProducingMilk = isProducingMilk; }

  getLitersOfMilkPerWeek(): number { return this.litersOfMilkPerWeek; }
  setLitersOfMilkPerWeek(litersOfMilkPerWeek: number): void { this.litersOfMilkPerWeek = litersOfMilkPerWeek; }
}
