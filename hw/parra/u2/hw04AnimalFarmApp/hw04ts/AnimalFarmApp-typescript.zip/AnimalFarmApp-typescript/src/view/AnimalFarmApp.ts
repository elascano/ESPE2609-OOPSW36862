import { FarmAnimal } from "../model/FarmAnimal.ts";
import { Chicken } from "../model/Chicken.ts";
import { Cow } from "../model/Cow.ts";
import { Pig } from "../model/Pig.ts";
import { Sheep } from "../model/Sheep.ts";

function main(): void {
  console.log("Hello this is Carlos's Animal Farm!");
  console.log("=====================================");

  const bornOnDate = new Date(2020, 10, 10);
  const farmAnimal: FarmAnimal = new Cow(true, 6, 10, "houlstein", bornOnDate);
  console.log("farmAnimal is a -->" + farmAnimal.constructor.name);
  console.log("my farm animal -->" + farmAnimal);

  const chicken = new Chicken(true, 10, true, 2, "Palish", new Date());
  console.log("Chicken -->" + chicken);
  chicken.layAnEgg();

  let farAnimalForFeeding: FarmAnimal = new Chicken(true, 20, true, 30, "Palish", bornOnDate);
  console.log("farAnimalForFeeding is a -->class " + farAnimalForFeeding.constructor.name);
  console.log("farAnimalForFeeding is a -->" + farAnimalForFeeding.constructor.name);

  farAnimalForFeeding = new Cow(true, 7, 5, "houlstein", bornOnDate);
  console.log("farAnimalForFeeding is a -->" + farAnimalForFeeding.constructor.name);

  farAnimalForFeeding = new Chicken(true, 5, true, 0, "Paliish", bornOnDate);
  console.log("farAnimalForFeeding is a -->" + farAnimalForFeeding.constructor.name);
  console.log("Cow -->" + farAnimalForFeeding);

  const cow = new Cow(true, 10, 20, "hlstein", bornOnDate);
  cow.milk();

  const pig: FarmAnimal = new Pig(true, 3, "Berkshire", new Date(2020, 15, 1));
  console.log("Pig -->" + pig);

  const sheep: FarmAnimal = new Sheep(new Date(), 4, "Merino", new Date(2023, 10, 5));
  console.log("Sheep -->" + sheep);
}

main();
