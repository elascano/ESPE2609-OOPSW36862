import { FarmAnimal } from "./FarmAnimal.ts";

export class Pig extends FarmAnimal {
  private isDelicious: boolean;

  constructor(isDelicious: boolean, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.isDelicious = isDelicious;
  }

  override toString(): string {
    return "Pig{" + super.toString() + "isDelicious=" + this.isDelicious + "}";
  }

  getIsDelicious(): boolean { return this.isDelicious; }
  setIsDelicious(isDelicious: boolean): void { this.isDelicious = isDelicious; }
}
