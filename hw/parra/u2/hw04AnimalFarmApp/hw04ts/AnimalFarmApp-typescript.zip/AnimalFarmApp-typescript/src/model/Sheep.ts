import { FarmAnimal } from "./FarmAnimal.ts";

export class Sheep extends FarmAnimal {
  private lastSheering: Date;

  constructor(lastSheering: Date, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.lastSheering = lastSheering;
  }

  sheering(): void {
    console.log("Las sheering in");
  }

  override toString(): string {
    return "Sheep{" + super.toString() + "lastSheering=" + this.lastSheering + "}";
  }

  getLastSheering(): Date { return this.lastSheering; }
  setLastSheering(lastSheering: Date): void { this.lastSheering = lastSheering; }
}
