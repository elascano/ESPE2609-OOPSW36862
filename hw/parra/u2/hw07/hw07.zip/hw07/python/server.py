from flask import Flask

PORT = 4017

app = Flask(__name__)


@app.get("/")
def welcome():
    return "Welcome to Carlos Parra server!"


if __name__ == "__main__":
    print(f"server is running on {PORT}")
    app.run(port=PORT)
