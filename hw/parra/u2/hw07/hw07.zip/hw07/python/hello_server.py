from http.server import BaseHTTPRequestHandler, HTTPServer

HOSTNAME = "127.0.0.1"
PORT = 5017


class HelloHandler(BaseHTTPRequestHandler):
    def respond(self):
        body = "hello, <b>Web Developers!</b> from <i>Carlos Parra</i>".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    do_GET = respond
    do_POST = respond
    do_PUT = respond
    do_DELETE = respond


if __name__ == "__main__":
    server = HTTPServer((HOSTNAME, PORT), HelloHandler)
    print(f"Carlos Parra running at http://{HOSTNAME}:{PORT}/")
    server.serve_forever()
