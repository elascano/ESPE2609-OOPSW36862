import express from "express";
import type { Request, Response } from "express";

const app = express();
const port = 4017;

app.get("/", (req: Request, res: Response) => {
  res.send("Welcome to Carlos Parra server!");
});

app.listen(port, () => {
  console.log(`server is running on ${port}`);
});
