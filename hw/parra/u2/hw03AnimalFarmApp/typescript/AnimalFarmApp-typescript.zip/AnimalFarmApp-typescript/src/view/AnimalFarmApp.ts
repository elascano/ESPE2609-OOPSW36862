import { FarmAnimal } from "../model/FarmAnimal.ts";
import { Chicken } from "../model/Chicken.ts";
import { Cow } from "../model/Cow.ts";

function main(): void {
  console.log("Hello this is Carlos's Anmail Farm!");
  console.log("===================================");

  const farmAnimal: FarmAnimal = new FarmAnimal(1, "Holstein", new Date());
  console.log("My farm animal is --->" + farmAnimal);

  const chicken = new Chicken(true, 10, false, 2, "palish", new Date(2022, 10, 10));
  console.log("chicken -->" + chicken);

  const cow: FarmAnimal = new Cow(true, 100.5, 3, "holstein", new Date(2022, 8, 20));
  console.log("Cow -->" + cow);
}

main();
