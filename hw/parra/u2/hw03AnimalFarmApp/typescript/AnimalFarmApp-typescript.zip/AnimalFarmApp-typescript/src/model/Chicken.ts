import { FarmAnimal } from "./FarmAnimal.ts";

export class Chicken extends FarmAnimal {
  private isMolting: boolean;
  private numberOfLaidEggsPerWeek: number;
  private isMeat: boolean;

  constructor(isMolting: boolean, numberOfLaidEggsPerWeek: number, isMeat: boolean, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.isMolting = isMolting;
    this.numberOfLaidEggsPerWeek = numberOfLaidEggsPerWeek;
    this.isMeat = isMeat;
  }

  override toString(): string {
    return "chicken{" + super.toString() + "isMolting=" + this.isMolting +
      ", numberOfLaidEggsInMonth=" + this.numberOfLaidEggsPerWeek + ", isMeat=" + this.isMeat + "}";
  }

  getIsMolting(): boolean { return this.isMolting; }
  setIsMolting(isMolting: boolean): void { this.isMolting = isMolting; }

  getNumberOfLaidEggsPerWeek(): number { return this.numberOfLaidEggsPerWeek; }
  setNumberOfLaidEggsPerWeek(n: number): void { this.numberOfLaidEggsPerWeek = n; }

  getIsMeat(): boolean { return this.isMeat; }
  setIsMeat(isMeat: boolean): void { this.isMeat = isMeat; }
}
