from datetime import date

from ec.edu.espe.animalfarmapp.model.chicken import Chicken
from ec.edu.espe.animalfarmapp.model.cow import Cow
from ec.edu.espe.animalfarmapp.model.farm_animal import FarmAnimal


def main() -> None:
    print("Hello this is Carlos's Anmail Farm!")
    print("===================================")

    farm_animal = FarmAnimal(1, "Holstein", date.today())
    print("My farm animal is --->" + str(farm_animal))

    chicken = Chicken(True, 10, False, 2, "palish", date(2022, 11, 10))
    print("chicken -->" + str(chicken))

    cow: FarmAnimal = Cow(True, 100.5, 3, "holstein", date(2022, 9, 20))
    print("Cow -->" + str(cow))


if __name__ == "__main__":
    main()
