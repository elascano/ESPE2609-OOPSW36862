from datetime import date

from ec.edu.espe.animalfarmapp.model.farm_animal import FarmAnimal


class Chicken(FarmAnimal):
    def __init__(self, is_molting: bool, number_of_laid_eggs_per_week: int, is_meat: bool,
                 id: int, breed: str, born_on_date: date):
        super().__init__(id, breed, born_on_date)
        self._is_molting = is_molting
        self._number_of_laid_eggs_per_week = number_of_laid_eggs_per_week
        self._is_meat = is_meat

    def __str__(self) -> str:
        return (f"chicken{{{super().__str__()}isMolting={str(self._is_molting).lower()}, "
                f"numberOfLaidEggsInMonth={self._number_of_laid_eggs_per_week}, "
                f"isMeat={str(self._is_meat).lower()}}}")

    @property
    def is_molting(self) -> bool:
        return self._is_molting

    @is_molting.setter
    def is_molting(self, value: bool) -> None:
        self._is_molting = value

    @property
    def number_of_laid_eggs_per_week(self) -> int:
        return self._number_of_laid_eggs_per_week

    @number_of_laid_eggs_per_week.setter
    def number_of_laid_eggs_per_week(self, value: int) -> None:
        self._number_of_laid_eggs_per_week = value

    @property
    def is_meat(self) -> bool:
        return self._is_meat

    @is_meat.setter
    def is_meat(self, value: bool) -> None:
        self._is_meat = value
