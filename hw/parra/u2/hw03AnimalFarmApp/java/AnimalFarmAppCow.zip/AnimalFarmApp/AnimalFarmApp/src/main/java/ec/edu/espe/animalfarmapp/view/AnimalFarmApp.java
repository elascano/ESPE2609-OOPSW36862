
package ec.edu.espe.animalfarmapp.view;

import ec.edu.espe.animalfarmapp.model.FarmAnimal;
import ec.edu.espe.animalfarmapp.model.Chicken;
import ec.edu.espe.animalfarmapp.model.Cow;
import java.util.Date;

/**
 *
 * @author Carlos Parra, ByteWorks, @ESPE
 */
public class AnimalFarmApp {

    public static void main(String[] args) {
        System.out.println("Hello this is Carlos's Anmail Farm!");
        System.out.println("===================================");
        FarmAnimal farmAnimal;
        farmAnimal = new FarmAnimal(1, "Holstein", new Date());
        
        System.out.println("My farm animal is --->" + farmAnimal);
        
        Chicken chicken = new Chicken(true, 10, false, 2, "palish", new Date(2022,10,10));
        System.out.println("chicken -->" + chicken); 
        
         FarmAnimal cow = new Cow(true, 100.5F, 3, "holstein", new Date(2022, 20, 20));
        System.out.println("Cow -->" + cow);
        
      
        
    }
}
