from datetime import date

from ec.espe.edu.animalfarmapp.model.chicken import Chicken
from ec.espe.edu.animalfarmapp.model.cow import Cow
from ec.espe.edu.animalfarmapp.model.farm_animal import FarmAnimal
from ec.espe.edu.animalfarmapp.model.food import Food


def full_class_name(animal: FarmAnimal) -> str:
    return "class ec.espe.edu.animalfarmapp.model." + type(animal).__name__


def main() -> None:
    born_on_date = date(2020, 11, 10)
    print("Hello this is Carlos's Animal Farm")
    print("===========================================================")

    food = Food("corn")
    farm_animal: FarmAnimal = Cow(True, 1, 10, "Holstein", born_on_date)
    farm_animal = Chicken(True, 1, True, 0, "Paliish", born_on_date)
    print("farmAnimal is a --> " + type(farm_animal).__name__)
    print("My farm animal --> " + str(farm_animal))

    chicken = Chicken(True, 10, True, 2, "Paleesh", born_on_date)
    print("Chicken ---> " + str(chicken))
    chicken.lay_an_egg()

    cow: FarmAnimal = Cow(True, 100.5, 3, "Holstein", born_on_date)
    print("cow is a --> " + type(cow).__name__)
    print("cow is a --> " + type(chicken).__name__)

    farm_animal_for_feeding: FarmAnimal = Chicken(True, 5, True, 0, "Paliish", born_on_date)
    print("farmAnimalForFeeding is a --> " + full_class_name(farm_animal_for_feeding))
    print("farmAnimalForFeeding is a --> " + type(farm_animal_for_feeding).__name__)

    farm_animal_for_feeding = Cow(True, 100.6, 0, "Holstein", born_on_date)
    print("farmAnimalForFeeding is a --> " + type(farm_animal_for_feeding).__name__)

    coww = Cow(True, 10, 5, "Holstein", date(1970, 1, 1))
    coww.milk()
    chicken.feed(food, 1)
    food = Food("grass")
    coww.feed(food, 1)
    coww.milk()
    coww.milk(3.5)
    coww.milk(20.5)
    coww.milk(100)


if __name__ == "__main__":
    main()
