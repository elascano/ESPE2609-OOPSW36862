from datetime import date, datetime
from typing import Optional, Union

from ec.espe.edu.animalfarmapp.model.farm_animal import FarmAnimal
from ec.espe.edu.animalfarmapp.model.food import Food
from ec.espe.edu.animalfarmapp.model.graze_animal import GrazeAnimal
from ec.espe.edu.animalfarmapp.model.location import Location


class Cow(FarmAnimal, GrazeAnimal):
    def __init__(self, is_producting_milk: bool, liters_of_milk_per_week: float,
                 id: int, breed: str, born_on_date: date):
        super().__init__(id, breed, born_on_date)
        self._is_producting_milk = is_producting_milk
        self._liters_of_milk_per_week = float(liters_of_milk_per_week)

    def milk(self, amount: Optional[Union[int, float]] = None, hour: Optional[datetime] = None) -> None:
        if amount is None:
            print("milking the cow as I need")
        elif hour is not None:
            print(f"milking the cow for {amount} liters, at {hour.hour}:{hour.minute}")
        elif isinstance(amount, int):
            self._liters_of_milk_per_week += amount
            print("milking the cow.... we got" + str(amount) + " liters")
        else:
            self._liters_of_milk_per_week += amount
            print(f"milking the cow for {float(amount)} liters")

    def graze(self, location: Location, date: date) -> None:
        print(f"Cow is grazing at --> {location}")

    def feed(self, food: Food, amount: int) -> None:
        print(f"feeding a cow in the stable with --> {food}")

    def __str__(self) -> str:
        return (f"Cow{{{super().__str__()}isProductingMilk={str(self._is_producting_milk).lower()}, "
                f"litersOfMilkPerWeek={self._liters_of_milk_per_week}}}")

    @property
    def is_producting_milk(self) -> bool:
        return self._is_producting_milk

    @is_producting_milk.setter
    def is_producting_milk(self, value: bool) -> None:
        self._is_producting_milk = value

    @property
    def liters_of_milk_per_week(self) -> float:
        return self._liters_of_milk_per_week

    @liters_of_milk_per_week.setter
    def liters_of_milk_per_week(self, value: float) -> None:
        self._liters_of_milk_per_week = float(value)
