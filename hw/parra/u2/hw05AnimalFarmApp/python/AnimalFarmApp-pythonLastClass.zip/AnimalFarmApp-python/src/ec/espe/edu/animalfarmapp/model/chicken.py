from datetime import date

from ec.espe.edu.animalfarmapp.model.farm_animal import FarmAnimal
from ec.espe.edu.animalfarmapp.model.food import Food


class Chicken(FarmAnimal):
    def __init__(self, is_molting: bool, number_of_laid_eggs_in_months: int, is_meat: bool,
                 id: int, breed: str, born_on_date: date):
        super().__init__(id, breed, born_on_date)
        self._is_molting = is_molting
        self._number_of_laid_eggs_in_months = number_of_laid_eggs_in_months
        self._is_meat = is_meat

    def feed(self, food: Food, amount: int) -> None:
        print(f"feeding a chicken with {amount} of {food}")

    def lay_an_egg(self) -> None:
        print("Chicken is laying an egg")

    def __str__(self) -> str:
        return (f"Chicken{{{super().__str__()}isMolting={str(self._is_molting).lower()}, "
                f"numberOfLaidEggsInMonths={self._number_of_laid_eggs_in_months}, "
                f"isMeat={str(self._is_meat).lower()}}}")

    @property
    def is_molting(self) -> bool:
        return self._is_molting

    @is_molting.setter
    def is_molting(self, value: bool) -> None:
        self._is_molting = value

    @property
    def number_of_laid_eggs_in_months(self) -> int:
        return self._number_of_laid_eggs_in_months

    @number_of_laid_eggs_in_months.setter
    def number_of_laid_eggs_in_months(self, value: int) -> None:
        self._number_of_laid_eggs_in_months = value

    @property
    def is_meat(self) -> bool:
        return self._is_meat

    @is_meat.setter
    def is_meat(self, value: bool) -> None:
        self._is_meat = value
