from abc import ABC, abstractmethod
from datetime import date

from ec.espe.edu.animalfarmapp.model.location import Location


class GrazeAnimal(ABC):
    @abstractmethod
    def graze(self, location: Location, date: date) -> None:
        ...
