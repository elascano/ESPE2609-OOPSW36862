from typing import Optional


class Location:
    def __init__(self, description: Optional[str] = None):
        self._description = description

    def __str__(self) -> str:
        shown = "null" if self._description is None else self._description
        return f"Location{{description={shown}}}"

    @property
    def description(self) -> Optional[str]:
        return self._description

    @description.setter
    def description(self, value: Optional[str]) -> None:
        self._description = value
