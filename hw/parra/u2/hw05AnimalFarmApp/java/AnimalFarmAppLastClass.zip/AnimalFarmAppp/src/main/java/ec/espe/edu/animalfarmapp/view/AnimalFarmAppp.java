/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.espe.edu.animalfarmapp.view;

import ec.espe.edu.animalfarmapp.model.Chicken;
import ec.espe.edu.animalfarmapp.model.Cow;
import ec.espe.edu.animalfarmapp.model.FarmAnimal;
import ec.espe.edu.animalfarmapp.model.Food;
import java.util.Date;

/**
 *
 * @author Carlos Parra, ByteWorks, @ESPE
 */
public abstract class AnimalFarmAppp {

    public static void main(String[] args) {
        Date bornOnDate = new Date(2020,10,10);
        System.out.println("Hello this is Carlos's Animal Farm");
        System.out.println("===========================================================");
        FarmAnimal farmAnimal;
        FarmAnimal farmAnimalForFeeding;
        Food food = new Food("corn");
        
        farmAnimal = new Cow(true, 1, 10, "Holstein", bornOnDate);
        
        farmAnimal = new Chicken(true, 1, true, 0, "Paliish", bornOnDate);
        
        System.out.println("farmAnimal is a --> " + farmAnimal.getClass().getSimpleName());
        
        System.out.println("My farm animal --> " + farmAnimal);
        
        Chicken chicken = new Chicken(true, 10, true, 2, "Paleesh", bornOnDate);
        System.out.println("Chicken ---> " + chicken);
        chicken.layAnEgg();
        
        FarmAnimal cow = new Cow(true, 100.5F, 3, "Holstein", bornOnDate);
        
        System.out.println("cow is a --> " + cow.getClass().getSimpleName());
        
        
        System.out.println("cow is a --> " + chicken.getClass().getSimpleName());
        
        farmAnimalForFeeding = new Chicken(true, 5, true, 0, "Paliish", bornOnDate);
        System.out.println("farmAnimalForFeeding is a --> " + farmAnimalForFeeding.getClass());
        System.out.println("farmAnimalForFeeding is a --> " + farmAnimalForFeeding.getClass().getSimpleName());
        
        farmAnimalForFeeding = new Cow(true, 100.6F, 0, "Holstein", bornOnDate);
        System.out.println("farmAnimalForFeeding is a --> " + farmAnimalForFeeding.getClass().getSimpleName());
        
        Cow coww = new Cow(true, 10, 5, "Holstein", new Date(10/10/2020));
        coww.milk();
        
        chicken.feed(food,1);
        
        food = new Food("grass");
        coww.feed(food, 1);
        
        //cow.sendToGraze(location,bornOnDate);
        
        
        coww.milk();
        coww.milk(3.5F);
        coww.milk(20.5F);
        coww.milk(100);

    }
}
