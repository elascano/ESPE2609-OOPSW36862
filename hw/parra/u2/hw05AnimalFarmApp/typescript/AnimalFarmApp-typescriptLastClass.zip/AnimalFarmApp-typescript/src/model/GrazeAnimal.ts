import type { Location } from "./Location.ts";

export interface GrazeAnimal {
  graze(location: Location, date: Date): void;
}
