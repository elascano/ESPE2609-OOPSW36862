import { FarmAnimal } from "../model/FarmAnimal.ts";
import { Chicken } from "../model/Chicken.ts";
import { Cow } from "../model/Cow.ts";
import { Food } from "../model/Food.ts";

function main(): void {
  const bornOnDate = new Date(2020, 10, 10);
  console.log("Hello this is Carlos's Animal Farm");
  console.log("===========================================================");

  let food = new Food("corn");
  let farmAnimal: FarmAnimal = new Cow(true, 1, 10, "Holstein", bornOnDate);
  farmAnimal = new Chicken(true, 1, true, 0, "Paliish", bornOnDate);
  console.log("farmAnimal is a --> " + farmAnimal.constructor.name);
  console.log("My farm animal --> " + farmAnimal);

  const chicken = new Chicken(true, 10, true, 2, "Paleesh", bornOnDate);
  console.log("Chicken ---> " + chicken);
  chicken.layAnEgg();

  const cow: FarmAnimal = new Cow(true, 100.5, 3, "Holstein", bornOnDate);
  console.log("cow is a --> " + cow.constructor.name);
  console.log("cow is a --> " + chicken.constructor.name);

  let farmAnimalForFeeding: FarmAnimal = new Chicken(true, 5, true, 0, "Paliish", bornOnDate);
  console.log("farmAnimalForFeeding is a --> class " + farmAnimalForFeeding.constructor.name);
  console.log("farmAnimalForFeeding is a --> " + farmAnimalForFeeding.constructor.name);

  farmAnimalForFeeding = new Cow(true, 100.6, 0, "Holstein", bornOnDate);
  console.log("farmAnimalForFeeding is a --> " + farmAnimalForFeeding.constructor.name);

  const coww = new Cow(true, 10, 5, "Holstein", new Date(0));
  coww.milk();
  chicken.feed(food, 1);
  food = new Food("grass");
  coww.feed(food, 1);
  coww.milk();
  coww.milk(3.5);
  coww.milk(20.5);
  coww.milk(100);
}

main();
