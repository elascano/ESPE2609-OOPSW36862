import { FarmAnimal } from "./FarmAnimal.ts";
import type { Food } from "./Food.ts";
import type { GrazeAnimal } from "./GrazeAnimal.ts";
import type { Location } from "./Location.ts";

export class Cow extends FarmAnimal implements GrazeAnimal {
  private isProductingMilk: boolean;
  private litersOfMilkPerWeek: number;

  constructor(isProductingMilk: boolean, litersOfMilkPerWeek: number, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.isProductingMilk = isProductingMilk;
    this.litersOfMilkPerWeek = litersOfMilkPerWeek;
  }

  milk(amount?: number, hour?: Date): void {
    if (amount === undefined) {
      console.log("milking the cow as I need");
    } else if (hour !== undefined) {
      console.log("milking the cow for " + amount + " liters, at " + hour.getHours() + ":" + hour.getMinutes());
    } else if (Number.isInteger(amount)) {
      this.litersOfMilkPerWeek += amount;
      console.log("milking the cow.... we got" + amount + " liters");
    } else {
      this.litersOfMilkPerWeek += amount;
      console.log("milking the cow for " + amount + " liters");
    }
  }

  graze(location: Location, date: Date): void {
    console.log("Cow is grazing at --> " + location);
  }

  override feed(food: Food, amount: number): void {
    console.log("feeding a cow in the stable with --> " + food);
  }

  private formatLiters(): string {
    return Number.isInteger(this.litersOfMilkPerWeek)
      ? this.litersOfMilkPerWeek.toFixed(1)
      : String(this.litersOfMilkPerWeek);
  }

  override toString(): string {
    return "Cow{" + super.toString() + "isProductingMilk=" + this.isProductingMilk +
      ", litersOfMilkPerWeek=" + this.formatLiters() + "}";
  }

  getIsProductingMilk(): boolean { return this.isProductingMilk; }
  setIsProductingMilk(isProductingMilk: boolean): void { this.isProductingMilk = isProductingMilk; }

  getLitersOfMilkPerWeek(): number { return this.litersOfMilkPerWeek; }
  setLitersOfMilkPerWeek(liters: number): void { this.litersOfMilkPerWeek = liters; }
}
