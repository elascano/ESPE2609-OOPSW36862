import { FarmAnimal } from "./FarmAnimal.ts";
import type { Food } from "./Food.ts";

export class Chicken extends FarmAnimal {
  private isMolting: boolean;
  private numberOfLaidEggsInMonths: number;
  private isMeat: boolean;

  constructor(isMolting: boolean, numberOfLaidEggsInMonths: number, isMeat: boolean, id: number, breed: string, bornOnDate: Date) {
    super(id, breed, bornOnDate);
    this.isMolting = isMolting;
    this.numberOfLaidEggsInMonths = numberOfLaidEggsInMonths;
    this.isMeat = isMeat;
  }

  override feed(food: Food, amount: number): void {
    console.log("feeding a chicken with " + amount + " of " + food);
  }

  layAnEgg(): void {
    console.log("Chicken is laying an egg");
  }

  override toString(): string {
    return "Chicken{" + super.toString() + "isMolting=" + this.isMolting +
      ", numberOfLaidEggsInMonths=" + this.numberOfLaidEggsInMonths + ", isMeat=" + this.isMeat + "}";
  }

  getIsMolting(): boolean { return this.isMolting; }
  setIsMolting(isMolting: boolean): void { this.isMolting = isMolting; }

  getNumberOfLaidEggsInMonths(): number { return this.numberOfLaidEggsInMonths; }
  setNumberOfLaidEggsInMonths(n: number): void { this.numberOfLaidEggsInMonths = n; }

  getIsMeat(): boolean { return this.isMeat; }
  setIsMeat(isMeat: boolean): void { this.isMeat = isMeat; }
}
