export class Location {
  private description: string | null;

  constructor(description: string | null = null) {
    this.description = description;
  }

  toString(): string {
    return "Location{description=" + this.description + "}";
  }

  getDescription(): string | null { return this.description; }
  setDescription(description: string | null): void { this.description = description; }
}
