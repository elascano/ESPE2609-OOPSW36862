import os

from pymongo import MongoClient


def connect_database():
    client = MongoClient(os.environ["MONGODB_URI"], serverSelectionTimeoutMS=10000)
    db = client.get_default_database()
    try:
        client.admin.command("ping")
        print("System connected to MongoDB Database")
    except Exception as error:
        print(error)
    return db
