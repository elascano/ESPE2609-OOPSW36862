from dataclasses import dataclass
from typing import Any, Optional

COLLECTION_NAME = "Customer"


@dataclass
class Customer:
    object_id: Optional[str]
    id: Optional[int]
    name: Optional[str]
    age: Optional[int]
    money_spent: Optional[float]

    @staticmethod
    def from_document(doc: dict[str, Any]) -> "Customer":
        return Customer(
            object_id=str(doc["_id"]) if "_id" in doc else None,
            id=doc.get("id"),
            name=doc.get("name"),
            age=doc.get("age"),
            money_spent=doc.get("moneySpent"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "_id": self.object_id,
            "id": self.id,
            "name": self.name,
            "age": self.age,
            "moneySpent": self.money_spent,
        }
