from dotenv import load_dotenv
from flask import Flask

from routes.customer_routes import create_customer_blueprint

PORT = 3017


def create_app(db) -> Flask:
    app = Flask(__name__)
    app.json.sort_keys = False
    app.register_blueprint(create_customer_blueprint(db), url_prefix="/computerstore")
    return app


if __name__ == "__main__":
    load_dotenv()
    from database import connect_database

    app = create_app(connect_database())
    print(f"Carlos Computers Store Server is running on port -> {PORT}")
    app.run(port=PORT)
