from flask import Blueprint, jsonify

from models.customer import COLLECTION_NAME, Customer


def create_customer_blueprint(db) -> Blueprint:
    customer_router = Blueprint("customer_router", __name__)

    @customer_router.get("/customers")
    def get_all_customers():
        try:
            customers = [Customer.from_document(doc).to_dict()
                         for doc in db[COLLECTION_NAME].find()]
            return jsonify(customers)
        except Exception as err:
            return jsonify({"message": str(err)}), 500

    return customer_router
