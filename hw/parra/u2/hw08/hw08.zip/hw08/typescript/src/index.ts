import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import { customerRouter } from "./routes/customerRoutes.ts";

const port = 3017;
const app = express();

const uri = process.env.MONGODB_URI;
if (!uri) {
  console.error("MONGODB_URI is not defined in the .env file");
  process.exit(1);
}

mongoose.connect(uri).catch((error: Error) => console.error(error.message));
const db = mongoose.connection;
db.on("error", (error) => console.error(error));
db.once("open", () => console.log("System connected to MongoDB Database"));

app.use(express.json());
app.use("/computerstore", customerRouter);
app.listen(port, () => console.log(`Carlos Computers Store Server is running on port -> ${port}`));
