import express from "express";
import type { Request, Response } from "express";
import { Customer } from "../models/Customer.ts";

export const customerRouter = express.Router();

customerRouter.get("/customers", async (req: Request, res: Response) => {
  try {
    const customers = await Customer.find();
    res.json(customers);
  } catch (err) {
    res.status(500).json({ message: err instanceof Error ? err.message : String(err) });
  }
});
