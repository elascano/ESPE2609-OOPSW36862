import mongoose from "mongoose";

export interface ICustomer {
  id: number;
  name: string;
  age: number;
  moneySpent: number;
}

const customerSchema = new mongoose.Schema<ICustomer>(
  {
    id: { type: Number },
    name: { type: String },
    age: { type: Number },
    moneySpent: { type: Number },
  },
  { collection: "Customer" },
);

export const Customer = mongoose.model<ICustomer>("Customer", customerSchema);
