import { FarmAnimal } from "./FarmAnimal";

export class Chicken extends FarmAnimal {
    private isMolting: boolean;
    private numberOfLaidEggsPerWeek: number;
    private isMeat: boolean;

    constructor(
        isMolting: boolean,
        numberOfLaidEggsPerWeek: number,
        isMeat: boolean,
        id: number,
        breed: string,
        bornOnDate: Date
    ) {
        super(id, breed, bornOnDate);
        this.isMolting = isMolting;
        this.numberOfLaidEggsPerWeek = numberOfLaidEggsPerWeek;
        this.isMeat = isMeat;
    }

    toString(): string {
        return `Chicken{${super.toString()}isMolting=${this.isMolting}, ` +
            `numberOfLaidEggsPerWeek=${this.numberOfLaidEggsPerWeek}, ` +
            `isMeat=${this.isMeat}}`;
    }

    getIsMolting(): boolean {
        return this.isMolting;
    }

    setIsMolting(isMolting: boolean): void {
        this.isMolting = isMolting;
    }

    getNumberOfLaidEggsPerWeek(): number {
        return this.numberOfLaidEggsPerWeek;
    }

    setNumberOfLaidEggsPerWeek(number: number): void {
        this.numberOfLaidEggsPerWeek = number;
    }

    getIsMeat(): boolean {
        return this.isMeat;
    }

    setIsMeat(isMeat: boolean): void {
        this.isMeat = isMeat;
    }
}
