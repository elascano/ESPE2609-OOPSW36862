import { FarmAnimal } from "./FarmAnimal";

export class Cow extends FarmAnimal {
    private isProducingMilk: boolean;
    private litersOfMilkPerWeek: number;
    private isMeat: boolean;

    constructor(
        isProducingMilk: boolean,
        litersOfMilkPerWeek: number,
        id: number,
        breed: string,
        bornOnDate: Date,
        isMeat: boolean = false
    ) {
        super(id, breed, bornOnDate);
        this.isProducingMilk = isProducingMilk;
        this.litersOfMilkPerWeek = litersOfMilkPerWeek;
        this.isMeat = isMeat;
    }

    toString(): string {
        return `Cow{${super.toString()}isProducingMilk=${this.isProducingMilk}, ` +
            `litersOfMilkPerWeek=${this.litersOfMilkPerWeek}, ` +
            `isMeat=${this.isMeat}}`;
    }

    milk(): void {
        console.log("Milking the cow");
    }

    getIsProducingMilk(): boolean {
        return this.isProducingMilk;
    }

    setIsProducingMilk(value: boolean): void {
        this.isProducingMilk = value;
    }

    getLitersOfMilkPerWeek(): number {
        return this.litersOfMilkPerWeek;
    }

    setLitersOfMilkPerWeek(value: number): void {
        this.litersOfMilkPerWeek = value;
    }

    getIsMeat(): boolean {
        return this.isMeat;
    }

    setIsMeat(value: boolean): void {
        this.isMeat = value;
    }
}
