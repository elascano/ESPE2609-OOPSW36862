import { FarmAnimal } from "./FarmAnimal";
import { Chicken } from "./Chicken";
import { Cow } from "./Cow";

console.log(" Renata's Animal Farm");
console.log("=====================");

const farmAnimal: FarmAnimal =
    new FarmAnimal(1, "holstein", new Date());

console.log("my farm animal is -->", farmAnimal.toString());

const chicken = new Chicken(
    true, 10, false, 2, "Palish", new Date(2022, 10, 10)
);
console.log("chicken -->", chicken.toString());

const cow: FarmAnimal = new Cow(
    true, 100.5, 3, "holstein", new Date()
);
console.log("cow -->", cow.toString());

console.log("Chicken age in months:", chicken.getAgeInMonths());
console.log("Cow age in months:", cow.getAgeInMonths());
