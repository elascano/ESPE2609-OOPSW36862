# AnimalFarmApp - TypeScript

## Instalar dependencias
```bash
npm install
```

## Compilar y ejecutar
```bash
npm run build
npm start
```

Si PowerShell bloquea `npm.ps1`, utiliza:
```powershell
npm.cmd install
npm.cmd run build
npm.cmd start
```

## Estructura
- `FarmAnimal.ts`: clase padre.
- `Chicken.ts`: clase hija Chicken.
- `Cow.ts`: clase hija Cow.
- `main.ts`: programa principal.
