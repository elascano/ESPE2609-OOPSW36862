export class FarmAnimal {
    private id: number;
    private breed: string;
    private bornOnDate: Date;

    constructor(id: number, breed: string, bornOnDate: Date) {
        this.id = id;
        this.breed = breed;
        this.bornOnDate = bornOnDate;
    }

    getAgeInMonths(): number {
        const today = new Date();
        let months =
            (today.getFullYear() - this.bornOnDate.getFullYear()) * 12;
        months += today.getMonth() - this.bornOnDate.getMonth();

        if (today.getDate() < this.bornOnDate.getDate()) {
            months--;
        }
        return Math.max(0, months);
    }

    toString(): string {
        return `id=${this.id}, breed=${this.breed}, bornOnDate=${
            this.bornOnDate.getDate()
        }/${this.bornOnDate.getMonth() + 1}/${
            this.bornOnDate.getFullYear()
        }, `;
    }

    getId(): number {
        return this.id;
    }

    setId(id: number): void {
        this.id = id;
    }

    getBreed(): string {
        return this.breed;
    }

    setBreed(breed: string): void {
        this.breed = breed;
    }

    getBornOnDate(): Date {
        return this.bornOnDate;
    }

    setBornOnDate(bornOnDate: Date): void {
        this.bornOnDate = bornOnDate;
    }
}
