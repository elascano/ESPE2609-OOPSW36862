# AnimalFarmApp - Python

## Ejecutar
Abre una terminal en esta carpeta y ejecuta:

```bash
python main.py
```

## Estructura
- `farm_animal.py`: clase padre.
- `chicken.py`: clase hija Chicken.
- `cow.py`: clase hija Cow.
- `main.py`: programa principal.

No necesita instalar librerías externas. Se utiliza `datetime` de Python.
