from datetime import date


class FarmAnimal:
    def __init__(self, animal_id: int, breed: str, born_on_date: date):
        self.id = animal_id
        self.breed = breed
        self.born_on_date = born_on_date

    def get_age_in_months(self) -> int:
        today = date.today()
        months = (today.year - self.born_on_date.year) * 12
        months += today.month - self.born_on_date.month
        if today.day < self.born_on_date.day:
            months -= 1
        return max(0, months)

    def __str__(self) -> str:
        return (
            f"id={self.id}, breed={self.breed}, "
            f"bornOnDate={self.born_on_date.day}/"
            f"{self.born_on_date.month}/{self.born_on_date.year}, "
        )

    def get_id(self) -> int:
        return self.id

    def set_id(self, animal_id: int) -> None:
        self.id = animal_id

    def get_breed(self) -> str:
        return self.breed

    def set_breed(self, breed: str) -> None:
        self.breed = breed

    def get_born_on_date(self) -> date:
        return self.born_on_date

    def set_born_on_date(self, born_on_date: date) -> None:
        self.born_on_date = born_on_date
