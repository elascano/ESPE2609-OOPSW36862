from datetime import date
from farm_animal import FarmAnimal
from chicken import Chicken
from cow import Cow


def main():
    print(" Renata's Animal Farm")
    print("=====================")

    farm_animal = FarmAnimal(1, "holstein", date.today())
    print("my farm animal is -->", farm_animal)

    chicken = Chicken(
        True, 10, False, 2, "Palish", date(2022, 11, 10)
    )
    print("chicken -->", chicken)

    cow = Cow(
        True, 100.5, 3, "holstein", date.today()
    )
    print("cow -->", cow)

    print("Chicken age in months:", chicken.get_age_in_months())
    print("Cow age in months:", cow.get_age_in_months())


if __name__ == "__main__":
    main()
