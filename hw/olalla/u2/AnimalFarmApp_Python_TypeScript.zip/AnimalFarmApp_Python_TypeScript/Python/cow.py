from datetime import date
from farm_animal import FarmAnimal


class Cow(FarmAnimal):
    def __init__(
        self,
        is_producing_milk: bool,
        liters_of_milk_per_week: float,
        animal_id: int,
        breed: str,
        born_on_date: date,
        is_meat: bool = False
    ):
        super().__init__(animal_id, breed, born_on_date)
        self.is_producing_milk = is_producing_milk
        self.liters_of_milk_per_week = liters_of_milk_per_week
        self.is_meat = is_meat

    def __str__(self) -> str:
        return (
            f"Cow{{{super().__str__()}"
            f"isProducingMilk={self.is_producing_milk}, "
            f"litersOfMilkPerWeek={self.liters_of_milk_per_week}, "
            f"isMeat={self.is_meat}}}"
        )

    def milk(self) -> None:
        print("Milking the cow")

    def get_is_producing_milk(self) -> bool:
        return self.is_producing_milk

    def set_is_producing_milk(self, value: bool) -> None:
        self.is_producing_milk = value

    def get_liters_of_milk_per_week(self) -> float:
        return self.liters_of_milk_per_week

    def set_liters_of_milk_per_week(self, value: float) -> None:
        self.liters_of_milk_per_week = value

    def get_is_meat(self) -> bool:
        return self.is_meat

    def set_is_meat(self, value: bool) -> None:
        self.is_meat = value
