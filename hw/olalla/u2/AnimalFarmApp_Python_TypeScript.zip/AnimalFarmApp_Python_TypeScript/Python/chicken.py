from datetime import date
from farm_animal import FarmAnimal


class Chicken(FarmAnimal):
    def __init__(
        self,
        is_molting: bool,
        number_of_laid_eggs_per_week: int,
        is_meat: bool,
        animal_id: int,
        breed: str,
        born_on_date: date
    ):
        super().__init__(animal_id, breed, born_on_date)
        self.is_molting = is_molting
        self.number_of_laid_eggs_per_week = number_of_laid_eggs_per_week
        self.is_meat = is_meat

    def __str__(self) -> str:
        return (
            f"Chicken{{{super().__str__()}"
            f"isMolting={self.is_molting}, "
            f"numberOfLaidEggsPerWeek={self.number_of_laid_eggs_per_week}, "
            f"isMeat={self.is_meat}}}"
        )

    def get_is_molting(self) -> bool:
        return self.is_molting

    def set_is_molting(self, is_molting: bool) -> None:
        self.is_molting = is_molting

    def get_number_of_laid_eggs_per_week(self) -> int:
        return self.number_of_laid_eggs_per_week

    def set_number_of_laid_eggs_per_week(self, number: int) -> None:
        self.number_of_laid_eggs_per_week = number

    def get_is_meat(self) -> bool:
        return self.is_meat

    def set_is_meat(self, is_meat: bool) -> None:
        self.is_meat = is_meat
