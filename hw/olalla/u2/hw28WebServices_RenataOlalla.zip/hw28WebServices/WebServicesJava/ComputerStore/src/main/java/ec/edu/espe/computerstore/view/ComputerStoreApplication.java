package ec.edu.espe.computerstore.view;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 *
 * @author Renata Olalla, Bynary Bosses, @ESPE
 */
@SpringBootApplication(scanBasePackages = "ec.edu.espe.computerstore")
@EnableMongoRepositories(basePackages = "ec.edu.espe.computerstore.repository")
public class ComputerStoreApplication{

    public static void main(String[] args) {
        System.out.println("Renata Olalla, Bynary Bosses, @ESPE - Computer Store");
        SpringApplication.run(ComputerStoreApplication.class, args);
    }
}