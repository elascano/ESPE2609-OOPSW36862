from fastapi import FastAPI
from routes.customerRoutes import router as customerRouter

print("Renata Olalla, Bynary Bosses, @ESPE - Computer Store (FastAPI)")
app = FastAPI()
app.include_router(customerRouter, prefix="/computerstore")
