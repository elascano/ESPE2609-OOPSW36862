declare const require: (moduleName: string) => any;
const fs = require('fs');

// 1. Definición de la clase Table
class Table {
    constructor(
        public id: string,
        public material: string,
        public legs: number,
        public price: number
    ) {}
}

// 2. Clase Administradora para manejar el Array y los archivos JSON
class TableManager {
    private tables: Table[] = [];
    private filename: string = 'tables.json';

    // Agregar objeto al Array
    public addTable(table: Table): void {
        this.tables.push(table);
    }

    // Guardar el Array en el archivo JSON
    public saveToJson(): void {
        const jsonData = JSON.stringify(this.tables, null, 2);
        fs.writeFileSync(this.filename, jsonData, 'utf-8');
        console.log(` Datos guardados exitosamente en ${this.filename}`);
    }

    // Leer el archivo JSON y mostrarlo en consola
    public readFromJson(): void {
        if (!fs.existsSync(this.filename)) {
            console.log(" El archivo JSON aún no existe.");
            return;
        }

        const fileContent = fs.readFileSync(this.filename, 'utf-8');
        const data: Table[] = JSON.parse(fileContent);

        console.log("\n--- LEYENDO DESDE EL ARCHIVO JSON ---");
        data.forEach((t, index) => {
            console.log(`[${index + 1}] ID: ${t.id} | Material: ${t.material} | Legs: ${t.legs} | Price: $${t.price}`);
        });
    }
}

// === EJECUCIÓN DEL PROGRAMA ===
const manager = new TableManager();

// Creando instancias de la clase Table
const table1 = new Table("T001", "Wood", 4, 120.50);
const table2 = new Table("T002", "Glass", 3, 250.00);

// Agregándolas al ArrayList
manager.addTable(table1);
manager.addTable(table2);

// Guardar en el archivo JSON
manager.saveToJson();

// Leer desde el archivo JSON
manager.readFromJson();