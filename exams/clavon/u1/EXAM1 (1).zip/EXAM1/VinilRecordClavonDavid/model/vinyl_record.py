class VinylRecord:
    def __init__(self, record_id: int, title: str, artist: str, release_year: int):
        self.id = record_id
        self.title = title
        self.artist = artist
        self.release_year = release_year

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "artist": self.artist,
            "release_year": self.release_year
        }

    @staticmethod
    def from_dict(data: dict) -> 'VinylRecord':
        return VinylRecord(
            record_id=data["id"],
            title=data["title"],
            artist=data["artist"],
            release_year=data["release_year"]
        )

    def __str__(self) -> str:
        return f"ID: {self.id} | Title: '{self.title}' | Artist: {self.artist} | Year: {self.release_year}"