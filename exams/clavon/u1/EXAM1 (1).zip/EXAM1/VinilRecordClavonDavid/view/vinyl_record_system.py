import sys
import os
import json

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from model.vinyl_record import VinylRecord

JSON_FILE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'vinyl_records.json'))

def save_to_json(records_list: list[VinylRecord]) -> None:
    data = [record.to_dict() for record in records_list]
    with open(JSON_FILE_PATH, mode='w', encoding='utf-8') as file:
        json.dump(data, file, indent=4, ensure_ascii=False)

def read_from_json() -> list[VinylRecord]:
    if not os.path.exists(JSON_FILE_PATH):
        return []
    try:
        with open(JSON_FILE_PATH, mode='r', encoding='utf-8') as file:
            data = json.load(file)
            return [VinylRecord.from_dict(item) for item in data]
    except (json.JSONDecodeError, KeyError):
        return []

def main():
    vinyl_records: list[VinylRecord] = read_from_json()

    while True:
        print("\n=== VINYL RECORD SYSTEM ===")
        print("1. Create and save Vinyl Record to JSON")
        print("2. Read Vinyl Records from JSON")
        print("3. Exit")
        option = input("Select an option: ").strip()

        if option == "1":
            try:
                record_id = int(input("Enter ID: "))
                title = input("Enter Title: ").strip()
                artist = input("Enter Artist: ").strip()
                release_year = int(input("Enter Release Year: "))

                new_vinyl = VinylRecord(record_id, title, artist, release_year)
                vinyl_records.append(new_vinyl)
                save_to_json(vinyl_records)
                print("-> Vinyl record saved successfully in vinyl_records.json!")
            except ValueError:
                print("-> Error: ID and Release Year must be integers.")

        elif option == "2":
            print("\n--- LIST OF VINYL RECORDS FROM JSON ---")
            vinyl_records = read_from_json()
            if not vinyl_records:
                print("No records found.")
            else:
                for vinyl in vinyl_records:
                    print(vinyl)

        elif option == "3":
            print("Exiting...")
            break
        else:
            print("-> invalid option, try again.")
            

if __name__ == "__main__":
    main()