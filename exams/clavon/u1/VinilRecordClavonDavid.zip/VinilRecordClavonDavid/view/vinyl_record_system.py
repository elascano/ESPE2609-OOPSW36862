import sys
import os
import json

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from model.vinyl_record import VinylRecord


class VinylRecordView:
    def __init__(self):
        self.json_file_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), '..', 'vinyl_records.json')
        )
        self.vinyl_records: list[VinylRecord] = self.read_from_json()

    def save_to_json(self) -> None:
        data = [record.to_dict() for record in self.vinyl_records]
        with open(self.json_file_path, mode='w', encoding='utf-8') as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

    def read_from_json(self) -> list[VinylRecord]:
        if not os.path.exists(self.json_file_path):
            return []
        try:
            with open(self.json_file_path, mode='r', encoding='utf-8') as file:
                data = json.load(file)
                return [VinylRecord.from_dict(item) for item in data]
        except (json.JSONDecodeError, KeyError):
            return []

    def display_menu(self) -> None:
        print("\n=== VINYL RECORD SYSTEM ===")
        print("1. Create and save Vinyl Record to JSON")
        print("2. Read Vinyl Records from JSON")
        print("3. Exit")

    def create_vinyl_record(self) -> None:
        try:
            record_id = int(input("Enter ID: "))
            title = input("Enter Title: ").strip()
            artist = input("Enter Artist: ").strip()
            release_year = int(input("Enter Release Year: "))

            new_vinyl = VinylRecord(record_id, title, artist, release_year)
            self.vinyl_records.append(new_vinyl)
            self.save_to_json()
            print("-> Vinyl record saved successfully in vinyl_records.json!")
        except ValueError:
            print("-> Error: ID and Release Year must be integers.")

    def show_vinyl_records(self) -> None:
        print("\n--- LIST OF VINYL RECORDS FROM JSON ---")
        self.vinyl_records = self.read_from_json()
        if not self.vinyl_records:
            print("No records found.")
        else:
            for vinyl in self.vinyl_records:
                print(vinyl)

    def start(self) -> None:
        while True:
            self.display_menu()
            option = input("Select an option: ").strip()

            if option == "1":
                self.create_vinyl_record()
            elif option == "2":
                self.show_vinyl_records()
            elif option == "3":
                print("Exiting...")
                break
            else:
                print("-> Invalid option, try again.")


if __name__ == "__main__":
    app = VinylRecordView()
    app.start()