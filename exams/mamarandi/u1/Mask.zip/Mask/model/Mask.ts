export class Mask {
  id: number;
  type: string;
  material: string;
  price: number;

  constructor(id: number, type: string, material: string, price: number) {
    this.id = id;
    this.type = type;
    this.material = material;
    this.price = price;
  }

  static fromJson(data: any): Mask {
    return new Mask(Number(data.id), String(data.type), String(data.material), Number(data.price));
  }

  toString(): string {
    return `Mask{id=${this.id}, type=${this.type}, material=${this.material}, price=$${this.price.toFixed(2)}}`;
  }
}
