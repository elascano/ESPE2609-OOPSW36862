import * as fs from 'node:fs';
import { Mask } from '../model/Mask';

export class MaskController {
  private filePath: string;
  private masks: Mask[] = [];

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  loadFromJson(): Mask[] {
    if (!fs.existsSync(this.filePath)) {
      this.masks = [];
      return this.masks;
    }
    const content = fs.readFileSync(this.filePath, 'utf8').trim();
    const data: any[] = content ? JSON.parse(content) : [];
    this.masks = data.map(item => Mask.fromJson(item));
    return this.masks;
  }

  saveToJson(): void {
    fs.writeFileSync(this.filePath, JSON.stringify(this.masks, null, 2), 'utf8');
  }

  addMask(mask: Mask): boolean {
    if (this.findById(mask.id)) {
      return false;
    }
    this.masks.push(mask);
    this.saveToJson();
    return true;
  }

  findById(maskId: number): Mask | undefined {
    return this.masks.find(mask => mask.id === maskId);
  }

  getAll(): Mask[] {
    return this.masks;
  }

  getFilePath(): string {
    return this.filePath;
  }
}
