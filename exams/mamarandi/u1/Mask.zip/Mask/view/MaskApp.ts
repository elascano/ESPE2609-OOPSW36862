import * as path from 'node:path';
import * as readline from 'node:readline';
import { MaskController } from '../controller/MaskController';
import { Mask } from '../model/Mask';

const rl = readline.createInterface({ input: process.stdin });
const pendingLines: string[] = [];
const waiting: ((line: string) => void)[] = [];

rl.on('line', line => {
  const resolve = waiting.shift();
  if (resolve) {
    resolve(line);
  } else {
    pendingLines.push(line);
  }
});
rl.on('close', () => {
  waiting.forEach(resolve => resolve('4'));
});

function ask(message: string): Promise<string> {
  process.stdout.write(message);
  const line = pendingLines.shift();
  if (line !== undefined) {
    return Promise.resolve(line);
  }
  return new Promise(resolve => waiting.push(resolve));
}

async function readInt(message: string): Promise<number> {
  while (true) {
    const value = Number((await ask(message)).trim());
    if (Number.isInteger(value) && value > 0) {
      return value;
    }
    console.log('  Invalid number, it must be an integer greater than 0.');
  }
}

async function readFloat(message: string): Promise<number> {
  while (true) {
    const text = (await ask(message)).trim();
    const value = Number(text);
    if (text !== '' && !Number.isNaN(value) && value > 0) {
      return value;
    }
    console.log('  Invalid number, it must be greater than 0.');
  }
}

async function readText(message: string): Promise<string> {
  while (true) {
    const value = (await ask(message)).trim();
    if (value) {
      return value;
    }
    console.log('  This field cannot be empty.');
  }
}

async function createMask(controller: MaskController): Promise<void> {
  console.log('\n--- Create Mask ---');
  const id = await readInt('Id: ');
  if (controller.findById(id)) {
    console.log(`  A mask with id ${id} already exists.`);
    return;
  }
  const type = await readText('Type: ');
  const material = await readText('Material: ');
  const price = await readFloat('Price ($): ');
  controller.addMask(new Mask(id, type, material, price));
  console.log('  Mask saved to:', controller.getFilePath());
}

function showMasks(controller: MaskController): void {
  console.log('\n--- Masks read from JSON file ---');
  const masks = controller.loadFromJson();
  if (masks.length === 0) {
    console.log('  No masks registered.');
    return;
  }
  masks.forEach(mask => console.log(' ', mask.toString()));
}

async function searchMask(controller: MaskController): Promise<void> {
  console.log('\n--- Search Mask ---');
  controller.loadFromJson();
  const id = await readInt('Id to search: ');
  const mask = controller.findById(id);
  console.log('  Found:', mask ? mask.toString() : 'Not found');
}

async function main(): Promise<void> {
  const filePath = path.resolve(__dirname, '..', '..', 'masks.json');
  const controller = new MaskController(filePath);
  controller.loadFromJson();

  while (true) {
    console.log('\n========= MASK SYSTEM =========');
    console.log('1. Create mask');
    console.log('2. Show masks (read JSON)');
    console.log('3. Search mask by id');
    console.log('4. Exit');
    const option = (await ask('Choose an option: ')).trim();
    if (option === '1') {
      await createMask(controller);
    } else if (option === '2') {
      showMasks(controller);
    } else if (option === '3') {
      await searchMask(controller);
    } else if (option === '4') {
      console.log('Goodbye!');
      break;
    } else {
      console.log('  Invalid option.');
    }
  }
  rl.close();
}

main();
