import json
import os
from typing import List

class Speaker:

    def __init__(self, speaker_id: str, brand: str, power_watts: int, price: float):
        self.id = speaker_id              
        self.brand = brand                
        self.power_watts = power_watts    
        self.price = price                
    def to_dict(self) -> dict:
        
        return {
            "id": self.id,
            "brand": self.brand,
            "power_watts": self.power_watts,
            "price": self.price
        }

    def from_dict(data: dict) -> 'Speaker':
    
        return Speaker(
            speaker_id=data["id"],
            brand=data["brand"],
            power_watts=data["power_watts"],
            price=data["price"]
        )

    def __str__(self) -> str:
        return f"ID: {self.id} | Marca: {self.brand} | Potencia: {self.power_watts}W | Precio: ${self.price:.2f}"

class SpeakerManager:
    

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.speakers: List[Speaker] = []

    def add_speaker(self, speaker: Speaker) -> None:
       
        self.speakers.append(speaker)

    def save_to_json(self) -> None:
      
        dir_name = os.path.dirname(self.file_path)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)

        data_to_save = [speaker.to_dict() for speaker in self.speakers]
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(data_to_save, f, indent=4, ensure_ascii=False)
        print("\n[OK] Datos de Altavoces guardados con éxito en el archivo JSON.")

    def load_from_json(self) -> List[Speaker]:
        if not os.path.exists(self.file_path):
            print("\n[!] El archivo JSON no existe aún. Se creará al guardar el primer registro.")
            return []

        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.speakers = [Speaker.from_dict(item) for item in data]
            print(f"\n[OK] Se cargaron {len(self.speakers)} registro(s) de Alvtavoz desde el JSON.")
        except (json.JSONDecodeError, KeyError) as e:
            print(f"\n[Error] Ocurrió un problema al leer el archivo JSON: {e}")
            self.speakers = []

        return self.speakers

def print_menu():
    print("\n" + "=" * 45)
    print("      SISTEMA DE GESTIÓN DE ALTAVOZ")
    print("=" * 45)
    print("1. Crear y Agregar ALtavos")
    print("2. Mostrar Speakers ")
    print("3. Salir")
    print("=" * 45)

def main():
    json_path = "speakers.json"
    manager = SpeakerManager(json_path)

    
    manager.load_from_json()

    while True:
        print_menu()
        option = input("Seleccione una opción: ").strip()

        if option == "1":
            print("\n--- INGRESO DE NUEVO REPRODUCTOR ---")
            speaker_id = input("Ingrese el ID: ").strip()
            brand = input("Ingrese la Marca (ej. JBL, Bose, Sony): ").strip()
            
            try:
                power_watts = int(input("Ingrese la Potencia en Watts (ej. 40): "))
                price = float(input("Ingrese el Precio (ej. 99.99): "))
            except ValueError:
                print("\n[Error] La potencia debe ser un entero y el precio un número decimal.")
                continue

            
            new_speaker = Speaker(speaker_id, brand, power_watts, price)
            manager.add_speaker(new_speaker)
            
            
            manager.save_to_json()

        elif option == "2":
            print("\n--- LISTA DE SPEAKERS DESDE JSON ---")
           
            speakers = manager.load_from_json()
            
            if not speakers:
                print("No hay speakers registrados actualmente.")
            else:
                for idx, speaker in enumerate(speakers, start=1):
                    print(f"{idx}. {speaker}")

        elif option == "3":
            print("\n¡Gracias por utilizar el sistema! Saliendo...")
            break
        else:
            print("\nOpción no válida. Intente nuevamente.")


if __name__ == "__main__":
    main()