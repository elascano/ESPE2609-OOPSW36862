/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ec.edu.espe.animalfarmapp.model;

import java.util.Date;

/**
 *
 * @author Renata Olalla,Binary Booses,@ESPE
 */
public interface GrazeAnimalI {

    public void sendToGraze(Location location, Date date);
}
