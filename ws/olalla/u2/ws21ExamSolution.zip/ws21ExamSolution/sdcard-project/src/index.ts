import * as readline from 'readline';
import { SDCard } from './SDCard';
import { SDCardManager } from './SDCardManager';

/**
 * @author Renata Olalla, Binary Bosses, @ESPE
 */
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const manager = new SDCardManager('sdcards.json');

// Helper to wrap readline prompt in a Promise
function prompt(query: string): Promise<string> {
    return new Promise(resolve => rl.question(query, resolve));
}

async function handleAddSDCard() {
    console.log('\n--- ADD NEW SD CARD ---');

    let id = '';
    while (!id) {
        id = (await prompt('Enter ID (e.g., SD-004): ')).trim();
        if (!id) {
            console.log('ID cannot be empty.');
        } else if (manager.exists(id)) {
            console.log(`An entry with ID "${id}" already exists. Please use a unique ID.`);
            id = '';
        }
    }

    let brand = '';
    while (!brand) {
        brand = (await prompt('Enter Brand (e.g., SanDisk): ')).trim();
        if (!brand) console.log('Brand cannot be empty.');
    }

    let type = '';
    while (!type) {
        type = (await prompt('Enter Type (SDHC / SDXC / SDUC): ')).trim().toUpperCase();
        if (!type) console.log('Type cannot be empty.');
    }

    let capacityGB = NaN;
    while (isNaN(capacityGB) || capacityGB <= 0) {
        const inputCapacity = await prompt('Enter Capacity in GB (e.g., 128): ');
        capacityGB = parseInt(inputCapacity, 10);
        if (isNaN(capacityGB) || capacityGB <= 0) {
            console.log('Please enter a valid positive capacity number.');
        }
    }

    // Instantiate object and add via manager
    const newSDCard = new SDCard(id, brand, type, capacityGB);
    manager.addSDCard(newSDCard);
}

function handleListSDCards() {
    console.log('\n--- SD CARD RECORDS (READ FROM JSON) ---');
    const list = manager.loadFromFile();

    if (list.length === 0) {
        console.log('No SD cards registered yet.');
        return;
    }

    list.forEach((sdCard, index) => {
        console.log(`[${index + 1}] ID: ${sdCard.getId()}`);
        console.log(`    Brand:      ${sdCard.getBrand()}`);
        console.log(`    Type:       ${sdCard.getType()}`);
        console.log(`    Capacity:   ${sdCard.getCapacityGB()} GB`);
        console.log('----------------------------------------------------');
    });
}

async function showMenu() {
    let running = true;

    while (running) {
        console.log('\n================ SD CARD SYSTEM MENU ================');
        console.log('1. Display all SD cards (Read from JSON)');
        console.log('2. Add a new SD card (Write to JSON)');
        console.log('3. Exit');
        console.log('=====================================================');

        const option = (await prompt('Select an option (1-3): ')).trim();

        switch (option) {
            case '1':
                handleListSDCards();
                break;
            case '2':
                await handleAddSDCard();
                break;
            case '3':
                console.log('\nExiting program. Goodbye!');
                running = false;
                rl.close();
                break;
            default:
                console.log('\nInvalid option. Please enter 1, 2, or 3.');
                break;
        }
    }
}

showMenu();
