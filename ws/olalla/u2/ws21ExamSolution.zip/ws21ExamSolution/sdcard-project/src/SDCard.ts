/**
 * @author Renata Olalla, Binary Bosses, @ESPE
 */
export class SDCard {
    private id: string;
    private brand: string;
    private type: string;
    private capacityGB: number;

    constructor(id: string, brand: string, type: string, capacityGB: number) {
        this.id = id;
        this.brand = brand;
        this.type = type;
        this.capacityGB = capacityGB;
    }

    public getId(): string {
        return this.id;
    }

    public getBrand(): string {
        return this.brand;
    }

    public getType(): string {
        return this.type;
    }

    public getCapacityGB(): number {
        return this.capacityGB;
    }

    public toJSON(): object {
        return {
            id: this.id,
            brand: this.brand,
            type: this.type,
            capacityGB: this.capacityGB
        };
    }

    public static fromJSON(obj: any): SDCard {
        return new SDCard(obj.id, obj.brand, obj.type, obj.capacityGB);
    }
}
