import * as fs from 'fs';
import * as path from 'path';
import { SDCard } from './SDCard';

/**
 * @author Renata Olalla, Binary Bosses, @ESPE
 */
export class SDCardManager {
    private sdCards: SDCard[] = [];
    private filePath: string;

    constructor(fileName: string = 'sdcards.json') {
        this.filePath = path.resolve(process.cwd(), fileName);
        this.loadFromFile();
    }

    // Add a new SD card and automatically save to JSON file
    public addSDCard(sdCard: SDCard): void {
        this.sdCards.push(sdCard);
        this.saveToFile();
    }

    // Check if ID already exists
    public exists(id: string): boolean {
        return this.sdCards.some(c => c.getId().toLowerCase() === id.toLowerCase());
    }

    public saveToFile(): void {
        try {
            const data = JSON.stringify(this.sdCards.map(c => c.toJSON()), null, 4);
            fs.writeFileSync(this.filePath, data, 'utf-8');
            console.log(`\n[SUCCESS] Saved ${this.sdCards.length} record(s) to JSON file.`);
        } catch (error) {
            console.error('\n[ERROR] Writing to JSON file:', error);
        }
    }

    public loadFromFile(): SDCard[] {
        if (!fs.existsSync(this.filePath)) {
            this.sdCards = [];
            return this.sdCards;
        }

        try {
            const rawData = fs.readFileSync(this.filePath, 'utf-8');
            const parsedData: any[] = JSON.parse(rawData);
            this.sdCards = parsedData.map(item => SDCard.fromJSON(item));
        } catch (error) {
            console.error('\n[ERROR] Reading from JSON file:', error);
            this.sdCards = [];
        }

        return this.sdCards;
    }

    public getSDCards(): SDCard[] {
        return this.sdCards;
    }
}
