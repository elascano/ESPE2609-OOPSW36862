# SDCard Class Diagram

**Author:** Renata Olalla, Binary Bosses, @ESPE

```
+-------------------------------------------------------+
|                        SDCard                         |
+-------------------------------------------------------+
| - id: string                                          |
| - brand: string                                       |
| - type: string                                        |
| - capacityGB: number                                  |
+-------------------------------------------------------+
| + constructor(id: string, brand: string,              |
|               type: string, capacityGB: number)       |
| + getId(): string                                     |
| + getBrand(): string                                  |
| + getType(): string                                   |
| + getCapacityGB(): number                             |
| + toJSON(): object                                    |
| + static fromJSON(obj: any): SDCard                   |
+-------------------------------------------------------+
                          ^
                          | uses
+-------------------------------------------------------+
|                    SDCardManager                      |
+-------------------------------------------------------+
| - sdCards: SDCard[]                                   |
| - filePath: string                                    |
+-------------------------------------------------------+
| + constructor(fileName: string)                       |
| + addSDCard(sdCard: SDCard): void                     |
| + exists(id: string): boolean                         |
| + saveToFile(): void                                  |
| + loadFromFile(): SDCard[]                            |
| + getSDCards(): SDCard[]                              |
+-------------------------------------------------------+
```
