# SD Card TypeScript Project - Execution Report

**Author:** Renata Olalla, Binary Bosses, @ESPE

## Execution Output

```text
================ SD CARD SYSTEM MENU ================
1. Display all SD cards (Read from JSON)
2. Add a new SD card (Write to JSON)
3. Exit
=====================================================
Select an option (1-3): 
--- SD CARD RECORDS (READ FROM JSON) ---
[1] ID: SD-001
    Brand:      SanDisk
    Type:       SDXC
    Capacity:   128 GB
----------------------------------------------------
[2] ID: SD-002
    Brand:      Kingston
    Type:       SDHC
    Capacity:   32 GB
----------------------------------------------------
[3] ID: SD-003
    Brand:      Samsung
    Type:       SDXC
    Capacity:   256 GB
----------------------------------------------------

================ SD CARD SYSTEM MENU ================
1. Display all SD cards (Read from JSON)
2. Add a new SD card (Write to JSON)
3. Exit
=====================================================
Select an option (1-3): 
--- ADD NEW SD CARD ---
Enter ID (e.g., SD-004): An entry with ID "SD-001" already exists. Please use a unique ID.
Enter ID (e.g., SD-004): Enter Brand (e.g., SanDisk): Enter Type (SDHC / SDXC / SDUC): Enter Capacity in GB (e.g., 128): 
[SUCCESS] Saved 4 record(s) to JSON file.

================ SD CARD SYSTEM MENU ================
1. Display all SD cards (Read from JSON)
2. Add a new SD card (Write to JSON)
3. Exit
=====================================================
Select an option (1-3): 
--- SD CARD RECORDS (READ FROM JSON) ---
[1] ID: SD-001
    Brand:      SanDisk
    Type:       SDXC
    Capacity:   128 GB
----------------------------------------------------
[2] ID: SD-002
    Brand:      Kingston
    Type:       SDHC
    Capacity:   32 GB
----------------------------------------------------
[3] ID: SD-003
    Brand:      Samsung
    Type:       SDXC
    Capacity:   256 GB
----------------------------------------------------
[4] ID: SD-004
    Brand:      Lexar
    Type:       SDXC
    Capacity:   512 GB
----------------------------------------------------

================ SD CARD SYSTEM MENU ================
1. Display all SD cards (Read from JSON)
2. Add a new SD card (Write to JSON)
3. Exit
=====================================================
Select an option (1-3): 
Exiting program. Goodbye!
```
