const fs = require('fs');
const path = require('path');
const Table = require('../model/table');

const FILE_PATH = path.join(__dirname, '../tables.json');
let tablesArray = [];

function readTablesFromJson() {
    try {
        if (fs.existsSync(FILE_PATH)) {
            const jsonData = fs.readFileSync(FILE_PATH, 'utf8');
            const parsedData = JSON.parse(jsonData);
            tablesArray = parsedData.map(t => new Table(t.id, t.tableNumber, t.capacity, t.status));
            console.log(" [SUCCESS] Data successfully read from 'tables.json'.");
        } else {
            console.log(" [INFO] 'tables.json' not found. Starting with an empty array.");
        }
    } catch (error) {
        console.error(" [ERROR] Failed to read from JSON file:", error.message);
    }
}

function saveTablesToJson() {
    try {
        const jsonData = JSON.stringify(tablesArray, null, 2);
        fs.writeFileSync(FILE_PATH, jsonData, 'utf8');
        console.log(" [SUCCESS] Data successfully saved to 'tables.json'.");
    } catch (error) {
        console.error(" [ERROR] Failed to write to JSON file:", error.message);
    }
}

function addTable(id, tableNumber, capacity, status) {
    const newTable = new Table(id, tableNumber, capacity, status);
    tablesArray.push(newTable);
    console.log(`\n[ADDED] ${newTable.getDetails()}`);
    saveTablesToJson();
}

console.log("--- Initializing Program & Reading JSON ---");
readTablesFromJson();

if (tablesArray.length === 0) {
    console.log("\n--- Adding Initial Tables ---");
    addTable("T-001", 1, 4, "Available");
    addTable("T-002", 2, 2, "Occupied");
    addTable("T-003", 3, 6, "Reserved");
} else {
    const dynamicId = `T-00${tablesArray.length + 1}`;
    addTable(dynamicId, tablesArray.length + 1, 4, "Available");
}

console.log("\n--- Current Tables in Memory (ArrayList) ---");
tablesArray.forEach((table, index) => {
    console.log(`[Index ${index}] ->`, table.getDetails());
});
