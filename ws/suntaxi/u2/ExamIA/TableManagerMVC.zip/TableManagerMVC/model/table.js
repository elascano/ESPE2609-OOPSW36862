class Table {
    constructor(id, tableNumber, capacity, status) {
        this.id = id;
        this.tableNumber = tableNumber;
        this.capacity = capacity;
        this.status = status;
    }

    getDetails() {
        return `Table ID: ${this.id}, Number: ${this.tableNumber}, Capacity: ${this.capacity}, Status: ${this.status}`;
    }
}

module.exports = Table;
