const port = 3000;
const express = require("express");
const app = express();
const mongoose = require("mongoose");

mongoose.connect("mongodb+srv://ajsuntaxi2_db_user:GeLkyofnydCU5DJw@cluster0.kziaghr.mongodb.net/oop");

const db = mongoose.connection;
db.on("error", (error) => console.error("MongoDB error:", error));
db.once("open", () => console.log("System connected to MongoDb Database"));

app.use(express.json());

const customerRouter = require("./routes/customerRouters");
app.use("/computerstore", customerRouter);

app.listen(port, () => {
  console.log(`Anghelo computers store server is running on port ${port}`);
});