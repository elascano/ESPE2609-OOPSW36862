
package ec.edu.espe.contracbook.model;

import java.util.Arrays;
import java.util.Date;

/**
 *
 * @author Dylan Cumbajin, MosQ, @ESPE
 */
public class Contact {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private boolean isKnown;
    private String cellPhoneNumber;
    private String type;
    private char grade;
    private String[] hobbies;
    private String instagram;
    private Date birthDate;

    // Empty constructor
    public Contact() {
    }

    // Constructor with parameters
    public Contact(int id, String firstName, String lastName,
            String email, boolean isKnown, String cellPhoneNumber,
            String type, char grade, String[] hobbies,
            String instagram, Date birthDate) {

        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.isKnown = isKnown;
        this.cellPhoneNumber = cellPhoneNumber;
        this.type = type;
        this.grade = grade;
        this.hobbies = hobbies;
        this.instagram = instagram;
        this.birthDate = birthDate;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isKnown() {
        return isKnown;
    }

    public void setKnown(boolean known) {
        isKnown = known;
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }

    public void setCellPhoneNumber(String cellPhoneNumber) {
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public char getGrade() {
        return grade;
    }

    public void setGrade(char grade) {
        this.grade = grade;
    }

    public String[] getHobbies() {
        return hobbies;
    }

    public void setHobbies(String[] hobbies) {
        this.hobbies = hobbies;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    
    
@Override
public String toString() {
    return "id=" + id
            + "\n firstName=" + firstName
            + "\n lastName=" + lastName
            + "\n email=" + email
            + "\n isKnown=" + isKnown
            + "\n cellPhoneNumber=" + cellPhoneNumber
            + "\n type=" + type
            + "\n grade=" + grade
            + "\n hobbies=" + Arrays.toString(hobbies)
            + "\n instagram=" + instagram
            + "\n birthDate=" + birthDate;
}



}
