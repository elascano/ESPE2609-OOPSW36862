const port = 3000;
const express = require("express");
const app = express();
const mongoose = require("mongoose");

mongoose.connect("mongodb+srv://dasangoquiza1_db_user:PZtLpCtxccVdj9xP@cluster0.fausufe.mongodb.net/oop");

const db = mongoose.connection;
db.on("error", (error) => console.error("MongoDB error:", error));
db.once("open", () => console.log("System connected to MongoDb Database"));

app.use(express.json());

const customerRouter = require("./routers/customerRouters");
app.use("/computerstore", customerRouter);

app.listen(port, () => {

  console.log(`Daniel's computers store server is running on port ${port}`);
});