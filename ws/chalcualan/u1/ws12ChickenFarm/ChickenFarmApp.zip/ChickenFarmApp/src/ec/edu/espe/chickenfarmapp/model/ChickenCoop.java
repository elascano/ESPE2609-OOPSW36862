package ec.edu.espe.chickenfarmapp.model;

/**
 *
 * @author Henry Chalcualan, Infinite Loops, @ESPE
 */
public class ChickenCoop {
    private int chickenCoop;
    private Chicken chickens[] = new Chicken[10];

    public ChickenCoop(int chickenCoop, Chicken[] chickens) {
        this.chickenCoop = chickenCoop;
        this.chickens = chickens;
    }

    @Override
    public String toString() {
        return "ChickenCoop{" + "chickenCoop=" + getChickenCoop() + ", chickens=" + getChickens() + '}';
    }

    /**
     * @return the chickenCoop
     */
    public int getChickenCoop() {
        return chickenCoop;
    }

    /**
     * @param chickenCoop the chickenCoop to set
     */
    public void setChickenCoop(int chickenCoop) {
        this.chickenCoop = chickenCoop;
    }

    /**
     * @return the chickens
     */
    public Chicken[] getChickens() {
        return chickens;
    }

    /**
     * @param chickens the chickens to set
     */
    public void setChickens(Chicken[] chickens) {
        this.chickens = chickens;
    }

    public void add(Chicken chicken){
        if(chickens.length < 10){
            
        }   
    }
    
    public void remove(){
        
    }
}
