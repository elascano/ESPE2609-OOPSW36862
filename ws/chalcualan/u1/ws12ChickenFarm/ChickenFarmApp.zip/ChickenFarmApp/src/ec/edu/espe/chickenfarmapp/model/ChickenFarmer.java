package ec.edu.espe.chickenfarmapp.model;

/**
 *
 * @author Henry Chalcualan, Infinite Loops, @ESPE
 */
public class ChickenFarmer {
    
}
