package ec.edu.espe.chickenfarmapp.view;

import ec.edu.espe.chickenfarmapp.model.Chicken;
import ec.edu.espe.chickenfarmapp.model.Egg;
import ec.edu.espe.chickenfarmapp.model.Poop;
import java.util.Date;

/**
 *
 * @author Henry Chalcualan, Infinite Loops, @ESPE
 */
public class ChickenFarmApp {
    public static void main(String args[]){
        System.out.println("Henry Chalcualan's Chicken Farm App");
        System.out.println("===================================");
        
        //variables declaration
        Chicken chicken;
        Chicken chicken1;
        Chicken[] chickens;
        Egg egg;
        Poop poop;
        
        //objects instantiation
        chicken = new Chicken(1, "Lucy", "brown and white", new Date(1970,11,17), true);//instantiation
        System.out.println("chicken --> " + chicken);
        
        egg = new Egg(1,'M');
        System.out.println("egg -->" + egg);
        
        poop = new Poop(1,"brown", 'S');
        System.out.println("poop -->" + poop);
        
        chicken1 = new Chicken(2, "Renata", "white", new Date(), false);//instantiation 
        System.out.println("chicken 2 -->" + chicken1);
        
        int localAge = chicken.computeAgeInYears();
        System.out.println("the age of the chicken -->" + localAge);
        
        chickens = new Chicken[10];
        chicken.doStuff();
        chickens[0] = new Chicken(3,"Pepita", "Black", new Date(2020,2,2), true);
        chickens[1] = chicken;
        
        int ageForTheLoop;
        for(int i=0; i< chickens.length;i++){
            ageForTheLoop = 2010 + i;
                    chickens[i]= new Chicken (i,"chicken" + (i+1), "white", new Date(ageForTheLoop,3,3), true);
                    chickens[i].computeAgeInYears();
        }
        for (int i = 0; i < chickens.length; i++) {
            System.out.println("chicken[" + i + "] --> " + chickens[i]);
        }
    }
}
